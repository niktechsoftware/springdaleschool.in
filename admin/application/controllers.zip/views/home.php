	<!-- REVOLUTION SLIDER
	============================================= -->
	<div class="fullwidthbanner-container top-shadow">
		<div class="fullwidthbanner">
			<ul><!-- Slide 2 -->
				<li data-masterspeed="300" data-slotamount="3" data-transition="fade">
				<!-- Main Image -->
				<img alt="" src="<?php echo base_url();?>assets/img/slider/Slider-8.jpg">
				<!-- End Main Image -->
				<!-- Captions -->
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="600" data-x="680" data-y="110">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/cmgw.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeOutExpo" data-speed="700" data-start="900" data-x="369" data-y="327">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-2.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeOutExpo" data-speed="700" data-start="1000" data-x="433" data-y="298">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-3.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeOutExpo" data-speed="700" data-start="1100" data-x="511" data-y="261">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-4.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeOutExpo" data-speed="700" data-start="1200" data-x="579" data-y="236">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-5.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeOutExpo" data-speed="700" data-start="1300" data-x="651" data-y="197">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-6.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeOutExpo" data-speed="1700" data-start="1700" data-x="360" data-y="24">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-7.png">
				</div>
				<div class="tp-caption fade" data-easing="easeOutExpo" data-speed="700" data-start="800" data-x="369" data-y="387">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/graph-1.png">
				</div>
				<div class="tp-caption m-3-2em m-text-black m-semibold sft" data-easing="easeOutExpo" data-speed="700" data-start="1400" data-x="40" data-y="-20">
					<img alt="" src="<?php echo base_url();?>assets/img/welcome.png">
				</div>
				<div class="tp-caption fade" data-easing="easeOutExpo" data-speed="700" data-start="1700" data-x="50" data-y="50">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/ashish.png">
				</div>
				<div class="tp-caption m-1-8em m-text-black sfr" data-easing="easeOutExpo" data-speed="700" data-start="2000" data-x="50" data-y="230">
					<span style="font-size: 12px;">Ravi Srivastava (Administrator)</span>
				</div>
				<div class="tp-caption fade" data-easing="easeOutExpo" data-speed="700" data-start="2300" data-x="300" data-y="50">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/prasanna.png">
				</div>
				<div class="tp-caption m-1-8em m-text-black sfr" data-easing="easeOutExpo" data-speed="700" data-start="2600" data-x="300" data-y="230">
					<span style="font-size: 12px;">Shashi Maurya (Director)</span>
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="300" data-start="3200" data-x="50" data-y="250">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/bank.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="300" data-start="3500" data-x="50" data-y="330">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/ssc.png">
				</div>
				
				<div class="tp-caption m-1-8em m-text-black sfr" data-easing="easeOutExpo" data-speed="700" data-start="2900" data-x="50" data-y="400">
					<span>You are Enering to world of Competition,SCI will make you a successful Competitor !</span>
				</div>
				<!-- End Captions -->
				</li>
				<!-- End Slide 2 -->
				<!-- Slide 1 -->
				<li data-masterspeed="300" data-slotamount="2" data-transition="fade">
				<!-- Main Image -->
				<img alt="" src="<?php echo base_url();?>assets/img/slider/Slider-8.jpg">
				<!-- End Main Image -->
				<!-- Captions -->
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="600" data-x="50" data-y="-50">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/SCI.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="700" data-start="1000" data-x="100" data-y="200">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/means.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="300" data-start="1400" data-x="230" data-y="160">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/success.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="700" data-start="1800" data-x="650" data-y="0">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/because.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="700" data-start="2200" data-x="750" data-y="100">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/together.png">
				</div>
				<div class="tp-caption m-1-8em m-text-black sfr" data-easing="easeOutExpo" data-speed="700" data-start="2600" data-x="680" data-y="285">
					<span>We Work together as a GROUP.....</span>
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="300" data-start="3000" data-x="620" data-y="360">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/bank.png">
				</div>
				<div class="tp-caption sfb" data-easing="easeInOutBack" data-speed="300" data-start="3400" data-x="860" data-y="370">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/ssc.png">
				</div>
				<!-- End Captions -->
				</li>
				<!-- End Slide 1 -->
				<!-- Slide 3 -->
				<li data-masterspeed="300" data-slotamount="4" data-transition="fade">
				<!-- Main Image -->
				<img alt="" src="<?php echo base_url();?>assets/img/slider/Slider-8.jpg">
				<!-- End Main Image -->
				<!-- Captions -->
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="600" data-x="670" data-y="34">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/women.png">
				</div>
				<div class="tp-caption fade" data-easing="easeOutExpo" data-speed="700" data-start="1300" data-x="670" data-y="34">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/men-2.png">
				</div>
				<div class="tp-caption fade" data-easing="easeOutExpo" data-speed="700" data-start="1300" data-x="50" data-y="-23">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/lightbulb-2.png">
				</div>
				<div class="tp-caption m-3-2em m-text-black m-semibold sft" data-easing="easeOutExpo" data-speed="700" data-start="1400" data-x="40" data-y="30">
					<img alt="" src="<?php echo base_url();?>assets/img/welcome2.png">
				</div>
				<div class="tp-caption m-1-8em m-text-black sfr" data-easing="easeOutExpo" data-speed="700" data-start="1600" data-x="40" data-y="150">
					<span>Success is continuous Journey....</span>
				</div>
				<div class="tp-caption m-1-8em m-text-black sfr" data-easing="easeOutExpo" data-speed="700" data-start="1600" data-x="120" data-y="195">
					<span>Achieve Milestones Step By Step...</span>
				</div>
				<!-- End Captions -->
				</li>
				<!-- End Slide 3 -->
				<!-- Slide 4 -->
				<li data-masterspeed="300" data-slotamount="1" data-transition="fade">
				<!-- Main Image -->
				<img alt="" src="<?php echo base_url();?>assets/img/slider/Slider-8.jpg">
				<!-- End Main Image -->
				<!-- Captions -->
				<div class="tp-caption m-3-2em m-text-black m-semibold sft" data-easing="easeOutExpo" data-speed="700" data-start="400" data-x="40" data-y="-30">
					<span>SCI'  MARVELOUS  EFFORT  To Make The OFFICERS</span>
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="600" data-x="60" data-y="28">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/ashwani.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="800" data-x="230" data-y="28">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/mohit.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="1000" data-x="400" data-y="28">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/shashank.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="1200" data-x="570" data-y="28">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/rajpreet.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="1400" data-x="750" data-y="28">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/anjani.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="1600" data-x="910" data-y="28">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/prabal.png">
				</div>
				
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="1800" data-x="140" data-y="228">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/nitesh.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="2000" data-x="310" data-y="228">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/neha.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="2200" data-x="480" data-y="228">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/amit.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="2400" data-x="650" data-y="228">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/tamanna.png">
				</div>
				<div class="tp-caption sfr" data-easing="easeOutExpo" data-speed="700" data-start="2600" data-x="830" data-y="228">
					<img alt="" src="<?php echo base_url();?>assets/img/slider/namita.png">
				</div>
				
				<!-- End Captions -->
				</li>
				<!-- End Slide 4 -->				
			</ul>
		</div>
	</div>
	<!-- END REVOLUTION SLIDER
	============================================= -->

	<!-- FEATURED CONTENT
	============================================= -->
	<div class="content content-featured">
		<div class="layout">
			<p>
				Your Selection.... Means Every thing to us, We are Committed to deliver Results. We care & It Shows in How we teach ?
			</p>
		</div>
	</div>
	<!-- END FEATURED CONTENT
	============================================= -->

	<!-- CONTENT 
	============================================= -->
	
	<div class="content">
		<div class="layout">
			<div class="gap" style="height: 10px;"></div>
			
			<!-- Promo Box -->
			<div class="b-promo margin-30">
				<a href="<?php echo base_url()?>welcome/register" class="btn big colored">Register with us !</a>
				<h3>Register with us for online test series.</h3>
				 You have fill a small form than submit the membership fee to SCI center for allow online test.
			</div>
			<!-- End Promo Box -->
			<div class="row">
				<div class="row-item col-1_2">
					<h3 class="lined margin-20">Enquiry Form</h3>
						<!-- Success Message -->
						<div class="form-message">
							<?php 
								if($this->uri->segment(3) == 'true'):
								$abc = str_replace("%20"," ",$this->uri->segment(4));
									echo "<font color='green'>Thank you <strong>".$abc."</strong> for contact us. We will touch with you soon....</font>";
								endif;
							?>
						</div>
						<!-- Form -->
						<form class="b-form" action="<?php echo base_url()?>apanelForms/inquiry" method="post">
							<div class="input-wrap m-full-width">
								<i class="icon-user"></i>
								<input class="field-name" type="text" placeholder="Name (required)" name="name" required="required">
							</div>
							<div class="input-wrap m-full-width">
								<i class="icon-mobile"></i>
								<input class="field-email" type="text" placeholder="Mobile Number (required)" name="mobile" required="required">
							</div>
							<div class="input-wrap m-full-width">
								<i class="icon-envelope"></i>
								<input class="field-email" type="text" placeholder="E-mail (required)" name="email" required="required">
							</div>
							<div class="textarea-wrap">
								<i class="icon-pencil"></i>
								<textarea class="field-comments" placeholder="Message" name="msg" required="required"></textarea>
							</div>
							<input class="btn-submit btn colored" type="submit" value="Send">
						</form>
						<!-- End Form -->
					<div class="gap" style="height: 20px;"></div>
				</div>
				<div class="row-item col-1_2">
					<h3 class="lined margin-20">Student Login !</h3>
					<!-- Form -->
						<form class="b-form" action="<?php echo base_url()?>loginController/stuLogin" method="post">
							<div class="input-wrap m-full-width">
								<i class="icon-user"></i>
								<input class="field-name" type="text" placeholder="Name (required)" name="name">
							</div>
							<div class="input-wrap m-full-width">
								<i class="icon-key"></i>
								<input class="field-email" type="text" placeholder="E-mail (required)" name="email">
							</div>
							<div class="m-full-width">
								 <a href="#">Forgot your password !</a>
                                    &nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;
                                    <a href="#">Are you a new Student ?</a>
							</div>
							<div>
								 <br/>
                                <label for="loginkeeping"><input type="checkbox" name="loginkeeping" id="loginkeeping" value="loginkeeping" /> Keep me logged in</label>
							</div>
							<br/>
							<input class="btn-submit btn colored" type="submit" value="Click for Login">
						</form>
					<!-- End Form -->
					<div class="gap" style="height: 20px;"></div>
				</div>
			</div>			
			
			<div class="gap" style="height: 10px;"></div>
			
			<div class="row">
				<div class="row-item col-1_2">
					<h3 class="lined margin-20">Why Join Our Group ?</h3>
					<ul class="b-list iconok m-circle">
						<li>SCI Knows what you need .... to get selected.</li>
						<li>We are comitted to get you state-of-the-art study material.</li>
						<li>Our Group uses unique method for classroom teaching.</li>
						<li>SCI Works with the students</li>
						<li>We Provide lucid explanations for all your questions.</li>
						<li>OUR GROUP believes in empowering you.</li>
						<li>SCI regularly tests you brfore the exams.</li>
						<li>WE leave no doubts unanswered.</li>
						<li>OUR GROUP believes in result oriented, student centric Teaching.</li>
					</ul>
					<div class="gap" style="height: 20px;"></div>
				</div>
				<div class="row-item col-1_2">
					<h3>Connect with facebook</h3>
						<div class="fb-page" data-href="https://www.facebook.com/careermakergroup" data-width="500" data-height="450" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/facebook"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote></div></div>
					<div class="gap" style="height: 20px;"></div>
				</div>
			</div>			
			
			<div class="gap" style="height: 10px;"></div>
			
			<h3 class="lined margin-20">Area we focused</h3>
			<div class="b-clients" style="margin-bottom: 10px;">
				<div class="client tooltips">
					<div class="tooltips-data">
						 Staff Selection Commission
					</div>
					<a href="#"><img src="<?php echo base_url();?>assets/img/elements/logo-1.jpg" alt=""></a>
				</div>
				<div class="client tooltips">
					<div class="tooltips-data">
						 IBPS
					</div>
					<a href="#"><img src="<?php echo base_url();?>assets/img/elements/logo-2.jpg" alt=""></a>
				</div>
				<div class="client tooltips">
					<div class="tooltips-data">
						 National Insurance
					</div>
					<a href="#"><img src="<?php echo base_url();?>assets/img/elements/logo-3.jpg" alt=""></a>
				</div>
				<div class="client tooltips">
					<div class="tooltips-data">
						 Reserve Bank of India
					</div>
					<a href="#"><img src="<?php echo base_url();?>assets/img/elements/logo-4.jpg" alt=""></a>
				</div>
				<div class="client tooltips">
					<div class="tooltips-data">
						 State Bank of india
					</div>
					<a href="#"><img src="<?php echo base_url();?>assets/img/elements/logo-5.jpg" alt=""></a>
				</div>
			</div>
			
			<div class="gap" style="height: 10px;"></div>
						
		</div>
	</div>
	<!-- END CONTENT 
	============================================= -->