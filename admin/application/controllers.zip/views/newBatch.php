	<!-- CONTENT 
	============================================= -->
	<div class="content shortcodes">
		<div class="layout">
			<div class="row">
				<img alt="Comming Soon" src="<?php echo base_url()?>assets/img/elements/img-1.png"/>
			</div>
		</div>
	</div>
	<!-- END CONTENT 
	============================================= -->
