<!-- CONTENT 
	============================================= -->
	<div class="content shortcodes">
		<div class="layout">
			
			<h3 class="lined margin-20">OUR SCI CLASSES TIMING</h3>
			
			<div class="row m-tariff-row">
				
				<div class="row-item col-1_4">
					
					<div class="b-tariff m-popular">
						<div class="popular-title m-turquoise">Regular Batch</div>
						<div class="tariff-head">
							<div class="tariff-title">daily</div>

							<div class="tariff-price">
								<span class="tariff-cy">Monday </span>
								<span class="tariff-cost">To</span>
								<span class="tariff-period"> Friday</span>
							</div>

							<p class="tariff-description">Our regular batches are running monday to friday.</p>
						</div>
						<ul class="tariff-meta">
							<li><mark class="green strong">OUR BATCH TIMING</mark></li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 07:30 AM - 09:30 AM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 10:00 AM - 12:00 PM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 12:00 PM - 02:00 PM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 03:00 PM - 05:00 PM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 05:30 PM - 07:30 PM</li>
						</ul>
					</div>

				</div>
				<div class="row-item col-1_4">
					
					<div class="b-tariff m-popular">
						<div class="popular-title m-turquoise">Weekend Batch</div>
						<div class="tariff-head">
							<div class="tariff-title">Weekend</div>

							<div class="tariff-price">
								<span class="tariff-cy">Saturday</span>
								<span class="tariff-cost">&</span>
								<span class="tariff-period">Sunday</span>
							</div>

							<p class="tariff-description">Our Weekend batches are running only Saturday and Sunday.</p>
						</div>
						<ul class="tariff-meta">
							<li><mark class="green strong">WEEKEND BATCH TIMING</mark></li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 12:00 PM - 4:00 AM</li>
							<li>We takes 4 houre class in weekend batches.</li>
						</ul>

						<a class="btn turquoise tariff-btn" href="#">Register</a>
					</div>

				</div>
				<div class="row-item col-1_4">
					
					<div class="b-tariff m-popular">
						<div class="popular-title m-turquoise">Mock Interview Batch</div>
						<div class="tariff-head">
							<div class="tariff-title">Mock Interview</div>

							<div class="tariff-price">
								<span class="tariff-cy">After</span>
								<span class="tariff-cost">20</span>
								<span class="tariff-period">Days</span>
							</div>

							<p class="tariff-description">of exam result decleartion mock interview porgram and class will start.</p>
						</div>
					</div>

				</div>
				<div class="row-item col-1_4">
					<div class="b-tariff m-popular">
						<div class="popular-title"><i class="icon-thumbs-up"></i>New Batches</div>
						<div class="tariff-head">
							<div class="tariff-title">Starts</div>

							<div class="tariff-price">
								<span class="tariff-cy">Every</span>
								<span class="tariff-cost">S</span>
								<span class="tariff-period">aturday</span>
							</div>

							<p class="tariff-description">New bteches starts on every saturday.</p>
						</div>
						<ul class="tariff-meta">
							<li><mark class="green strong">NEW BATCH TIMING</mark></li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 07:30 AM - 09:30 AM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 10:00 AM - 12:00 PM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 12:00 PM - 02:00 PM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 03:00 PM - 05:00 PM</li>
							<li><i class="icon-time" style="color: #73ca3f;"></i> 05:30 PM - 07:30 PM</li>
						</ul>
					</div>						

				</div>
			</div>
			
			<div class="gap" style="height: 30px;">
			</div>
			</div>

		</div>
	</div>
	<!-- END CONTENT 
	============================================= -->
