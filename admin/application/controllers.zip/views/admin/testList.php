                <div id="main-wrapper" class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-white">
                            	<div class="panel-body">
                                   <div class="table-responsive">
                                    <table id="example" class="display table" style="width: 100%; cellspacing: 0;">
                                        <thead>
                                            <tr>
                                            	<th>#</th>
                                                <th>Test ID</th>
                                                <th>Test Name</th>
                                                <th>Total Question</th>
                                                <th>Marks Per Question</th>
                                                <th>Nigatieve Marks</th>
                                                <th>Max Time</th>
                                                <th>1 Section</th>
                                                <th>2 Section</th>
                                                <th>3 Section</th>
                                                <th>4 Section</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	<?php $i = 1;?>
                                        	<?php $res = $this->db->get("create_test")->result();?>
                                        	<?php foreach($res as $row):?>
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td><?php echo $row->test_id; ?></td>
                                                <td><?php echo $row->test_name; ?></td>
                                                <td><?php echo $row->total_question; ?></td>
                                                <td><?php echo $row->marks_per_question; ?></td>
                                                <td><?php echo $row->nigatieve_marks; ?></td>
                                                <td><?php echo $row->max_time; ?></td>
                                                <td><?php echo $row->first_section_name."(".$row->ques1.")"; ?></td>
                                                <td><?php echo $row->second_section_name."(".$row->ques2.")"; ?></td>
                                                <td><?php echo $row->third_section_name."(".$row->ques3.")"; ?></td>
                                                <td><?php echo $row->fourth_section_name."(".$row->ques4.")"; ?></td>
                                                <td><?php echo date("d-M-Y",strtotime($row->date)); ?></td>
                                            </tr>
                                            <?php $i++;?>
                                            <?php endforeach;?>
                                        </tbody>
                                       </table>  
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row -->
                </div><!-- Main Wrapper -->