                <div id="main-wrapper" class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-white">
                            	<div class="panel-heading clearfix">
                                    <h4 class="panel-title">Create Test</h4>
                                </div>
                            	<div class="panel-body">
                                	<form class="form-horizontal" action="<?php echo base_url()?>apanelForms/createTest" method="post">
                                        <div class="row">
                                        	<div class="col-md-12" id="testError" style="text-align: center;"></div>
                                       	</div>
                                        <div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label for="input-Default" class="col-sm-5 control-label">
		                                            Test ID (witch is never used)
		                                            </label>
		                                            <div class="col-sm-7">
		                                                <input type="text" class="form-control" id="testId" name="test_id" required="required">
		                                            </div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label class="col-sm-4 control-label">Test Name</label>
		                                            <div class="col-sm-7">
		                                            	<input type="text" class="form-control" id="input-Default" name="test_name" required="required">
		                                            </div>
		                                        </div>
                                        	</div>
                                        </div>
                                        
                                        <div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label for="input-Default" class="col-sm-5 control-label">Total Questions</label>
		                                            <div class="col-sm-7">
		                                                <input type="number" name="total_question" class="form-control" id="totalQ" onkeypress="return IsNumeric(event);" ondrop="return false;" onpaste="return false;" required="required">
                                            			<span id="error" style="color: Red; display: none">* Input digits (0 - 9)</span>
													    <script type="text/javascript">
													        var specialKeys = new Array();
													        specialKeys.push(8); //Backspace
													        function IsNumeric(e) {
													            var keyCode = e.which ? e.which : e.keyCode
													            var ret = ((keyCode >= 48 && keyCode <= 57 ) || specialKeys.indexOf(keyCode) != -1);
													            document.getElementById("error").style.display = ret ? "none" : "inline";
													            return ret;
													        }
													    </script>
		                                            </div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label class="col-sm-4 control-label">Marks per Question</label>
		                                            <div class="col-sm-7">
		                                            	<input type="number" name="marks_per_question" class="form-control" id="text12" onkeypress="return IsNumeric1(event);" ondrop="return false;" onpaste="return false;" required="required">
                                            			<span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
													    <script type="text/javascript">
													        var specialKeys = new Array();
													        specialKeys.push(8); //Backspace
													        function IsNumeric1(e) {
													            var keyCode = e.which ? e.which : e.keyCode
													            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
													            document.getElementById("error1").style.display = ret ? "none" : "inline";
													            return ret;
													        }
													    </script>
		                                            </div>
		                                        </div>
                                        	</div>
                                        </div>
                                        
                                        <div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label for="input-Default" class="col-sm-5 control-label">Negative Marks</label>
		                                            <div class="col-sm-7">
		                                                <input type="text" name="nigatieve_marks" class="form-control" id="nigatieve_marks" required="required">
                                            		</div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label class="col-sm-4 control-label">Define Max Time</label>
		                                            <div class="col-sm-7">
		                                            	<select class="form-control" name="max_time">
		                                            		<option value="30">30 Min</option>
		                                            		<option value="60">60 Min</option>
		                                            		<option value="90">90 Min</option>
		                                            		<option value="120">120 Min</option>
		                                            		<option value="150">150 Min</option>
		                                            		<option value="180">180 Min</option>
		                                            		<option value="210">210 Min</option>
		                                            	</select>
		                                            </div>
		                                        </div>
                                        	</div>
                                        </div>
                                        
                                        <hr/>
                                        <div class="panel-heading clearfix">
		                                    <h4 class="panel-title">Define Test Sections Name</h4>
		                                </div>
                                        <div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label for="input-Default" class="col-sm-5 control-label">1st Section Name</label>
		                                            <div class="col-sm-7">
		                                                <input type="text" name="first_section_name" class="form-control" id="input-Default" name="title" required="required">
		                                            </div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
                                        	<div class="form-group">
		                                            <label class="col-sm-4 control-label">Question in 1st Section</label>
		                                            <div class="col-sm-7">
		                                            	<input type="number" name="ques1" class="form-control" id="1ques" onkeypress="return IsNumeric4(event);" ondrop="return false;" onpaste="return false;" required="required">
                                            			<span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
													    <script type="text/javascript">
													        var specialKeys = new Array();
													        specialKeys.push(8); //Backspace
													        function IsNumeric4(e) {
													            var keyCode = e.which ? e.which : e.keyCode
													            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
													            document.getElementById("error1").style.display = ret ? "none" : "inline";
													            return ret;
													        }
													    </script>
		                                            </div>
		                                        </div>
		                                	</div>
		                               	</div>
                                       	<div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label class="col-sm-5 control-label">2nd Section Name</label>
		                                            <div class="col-sm-7">
		                                            	<input type="text" name="second_section_name" class="form-control" id="input-Default" name="title">
		                                            </div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
                                        		<div class="form-group">
		                                            <label class="col-sm-4 control-label">Question in 2nd Section</label>
		                                            <div class="col-sm-7">
		                                            	<input type="number" name="ques2" class="form-control" id="2ques" onkeypress="return IsNumeric5(event);" ondrop="return false;" onpaste="return false;" required="required">
                                            			<span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
													    <script type="text/javascript">
													        var specialKeys = new Array();
													        specialKeys.push(8); //Backspace
													        function IsNumeric5(e) {
													            var keyCode = e.which ? e.which : e.keyCode
													            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
													            document.getElementById("error1").style.display = ret ? "none" : "inline";
													            return ret;
													        }
													    </script>
		                                            </div>
		                                        </div>
		                                     </div>
                                        </div>
                                        <div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label for="input-Default" class="col-sm-5 control-label">3rd Section Name</label>
		                                            <div class="col-sm-7">
		                                                <input type="text" name="third_section_name" class="form-control" id="input-Default" name="title">
		                                            </div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
                                        		<div class="form-group">
		                                            <label class="col-sm-4 control-label">Question in 3rd Section</label>
		                                            <div class="col-sm-7">
		                                            	<input type="number" name="ques3" class="form-control" id="3ques" onkeypress="return IsNumeric6(event);" ondrop="return false;" onpaste="return false;" required="required">
                                            			<span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
													    <script type="text/javascript">
													        var specialKeys = new Array();
													        specialKeys.push(8); //Backspace
													        function IsNumeric6(e) {
													            var keyCode = e.which ? e.which : e.keyCode
													            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
													            document.getElementById("error1").style.display = ret ? "none" : "inline";
													            return ret;
													        }
													    </script>
		                                            </div>
		                                    	</div>
		                                   </div>
		                               	</div>
                                       	<div class="row">
                                        	<div class="col-md-6">
		                                        <div class="form-group">
		                                            <label class="col-sm-5 control-label">4th Section Name</label>
		                                            <div class="col-sm-7">
		                                            	<input type="text" name="fourth_section_name" class="form-control" id="input-Default" name="title">
		                                            </div>
		                                        </div>
                                        	</div>
                                        	<div class="col-md-6">
                                        		<div class="form-group">
		                                            <label class="col-sm-4 control-label">Question in 4th Section</label>
		                                            <div class="col-sm-7">
		                                            	<input type="number" name="ques4" class="form-control" id="4ques" onkeypress="return IsNumeric7(event);" ondrop="return false;" onpaste="return false;" required="required">
                                            			<span id="error1" style="color: Red; display: none">* Input digits (0 - 9)</span>
													    <script type="text/javascript">
													        var specialKeys = new Array();
													        specialKeys.push(8); //Backspace
													        function IsNumeric7(e) {
													            var keyCode = e.which ? e.which : e.keyCode
													            var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
													            document.getElementById("error1").style.display = ret ? "none" : "inline";
													            return ret;
													        }
													    </script>
		                                            </div>
		                                        </div>
		                               		</div>
                                        </div>
                                        
                                         <div class="col-sm-offset-2 col-sm-10">
                                            <button type="submit" class="btn btn-success">Save Heading</button>
                                         </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row -->
                </div><!-- Main Wrapper -->