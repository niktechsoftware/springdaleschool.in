                <div id="main-wrapper" class="container">
                	<div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-white">
                            	<div class="panel-body">
                                	<div class="row">
                        				<div class="col-md-4">
                        					<select class="form-control" id="testId">
                        						<option value="">-Select Test ID-</option>
                        						<?php $val = $this->db->get("create_test")->result();?>
                        						<?php foreach($val as $row):?>
                        						<option value="<?php echo $row->test_id;?>"><?php echo $row->test_id;?></option>
                        						<?php endforeach;?>
                        					</select>
                        				</div>
                        				<div class="col-md-4">
                        					<select class="form-control" id="section"></select>
                        				</div>
                        				<div class="col-md-4">
                        					<select class="form-control" id="language"></select>
                        				</div>
                        			</div>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row -->
                	
                	<div class="row">
                        <div class="col-md-12" id="qList">
                        </div>
                    </div><!-- Row -->
                    
                </div><!-- Main Wrapper -->