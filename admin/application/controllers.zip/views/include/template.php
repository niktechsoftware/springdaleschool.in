<?php
$this->load->view("include/header");
$this->load->view($body);
$this->load->view("include/footer");
?>