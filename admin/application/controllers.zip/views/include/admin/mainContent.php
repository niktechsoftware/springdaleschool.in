<?php
	$this->load->view('include/admin/header');
	$this->load->view('include/admin/menu');
	$this->load->view($body);
	$this->load->view('include/admin/footer');
?>