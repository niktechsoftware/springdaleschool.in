<!-- TITLE BAR
	============================================= -->
	<div class="b-titlebar">
		<div class="layout">
			<!-- Bread Crumbs -->
			<ul class="crumbs">
				<li>You are here:</li>
				<li><a href="#">Courses</a></li>
				<?php if($this->uri->segment(3) == "sbiPo"): ?>
					<li><a href="#">Bank</a></li>
					<li><a href="#">SBI</a></li>
					<li><a href="#">PO</a></li>
				<?php elseif($this->uri->segment(3) == "sbiSo"): ?>
					<li><a href="#">Bank</a></li>
					<li><a href="#">SBI</a></li>
					<li><a href="#">SO</a></li>
				<?php elseif($this->uri->segment(3) == "sbiClerk"): ?>
                	<li><a href="#">Bank</a></li>
					<li><a href="#">SBI</a></li>
					<li><a href="#">Clerk</a></li>
                <?php elseif($this->uri->segment(3) == "rbiClark"): ?>
                    <li><a href="#">Bank</a></li>
					<li><a href="#">RBI</a></li>
					<li><a href="#">Clerk</a></li>
                <?php elseif($this->uri->segment(3) == "rbiManager"): ?>
                    <li><a href="#">Bank</a></li>
					<li><a href="#">RBI</a></li>
					<li><a href="#">Manager</a></li>
                <?php elseif($this->uri->segment(3) == "ibpsPo"): ?>
                    <li><a href="#">Bank</a></li>
					<li><a href="#">IBPS</a></li>
					<li><a href="#">IBPS PO</a></li>
					
                <?php elseif($this->uri->segment(3) == "ibpsSo"): ?>
                    <li><a href="#">Bank</a></li>
					<li><a href="#">IBPS</a></li>
					<li><a href="#">IBPS SO</a></li>
					
                <?php elseif($this->uri->segment(3) == "sscLdc"): ?>
                    <li><a href="#">SSC</a></li>
					<li><a href="#">Lower Devisional Clerk (LDC-XII)</a></li>
					
                <?php elseif($this->uri->segment(3) == "sscCgl"): ?>
                    <li><a href="#">SSC</a></li>
					<li><a href="#">Combined Graduate Level (CGL Graduate)</a></li>
                    
                <?php elseif($this->uri->segment(3) == "nicl"): ?>
            		<li><a href="#">Insurance</a></li>
					<li><a href="#">NICL</a></li>
                    
				<?php elseif($this->uri->segment(3) == "lic"): ?>
                	<li><a href="#">Insurance</a></li>
					<li><a href="#">LIC</a></li>
                    
                <?php elseif($this->uri->segment(3) == "oicl"): ?>
                 	<li><a href="#">Insurance</a></li>
					<li><a href="#">OICL</a></li>
                    
                <?php elseif($this->uri->segment(3) == "gic"): ?>
                 	<li><a href="#">Insurance</a></li>
					<li><a href="#">GIC</a></li>
                    
                <?php elseif($this->uri->segment(3) == "uicl"): ?>
                	<li><a href="#">Insurance</a></li>
					<li><a href="#">UIICL</a></li>
                    
				<?php endif; ?>
			</ul>
			<!-- Title -->
			<?php if($this->uri->segment(3) == "sbiPo"): ?>
				<h1>About SBI (PO)</h1>
			<?php elseif($this->uri->segment(3) == "sbiSo"): ?>
				<h1>About SBI (SO)</h1>
			<?php elseif($this->uri->segment(3) == "sbiClerk"): ?>
           		<h1>About SBI Clerk</h1>
            <?php elseif($this->uri->segment(3) == "rbiClark"): ?>
                <h1>RBI Clerk </h2>
            <?php elseif($this->uri->segment(3) == "rbiManager"): ?>
                <h1>RBI Manager</h1>
            <?php elseif($this->uri->segment(3) == "ibpsPo"): ?>
                <h1>About IBPS (PO)</h1>
            <?php elseif($this->uri->segment(3) == "ibpsSo"): ?>
				<h1>IBPS SO</h1>					
            <?php elseif($this->uri->segment(3) == "sscLdc"): ?>
                <h1>SSC LDC</h1>
            <?php elseif($this->uri->segment(3) == "sscCgl"): ?>
				<h1>SSC CGL</h1>
            <?php elseif($this->uri->segment(3) == "nicl"): ?>
            	<h1>National Insurance Company Ltd. (NICL)</h1>
            <?php elseif($this->uri->segment(3) == "lic"): ?>
            	<h1>Life Insurance Corporation of India (LIC)</h1>
            <?php elseif($this->uri->segment(3) == "oicl"): ?>
             	<h1>Oriental Insurance Company Ltd (OICL)</h1>
            <?php elseif($this->uri->segment(3) == "gic"): ?>
             	<h1>General Insurance Corporation of India (GIC)</h1>
            <?php elseif($this->uri->segment(3) == "uicl"): ?>
             	<h1>United India Insurance Company Limited (UIICL)</h1>
			<?php endif; ?>
		</div>
	</div>
	<!-- END TITLE BAR
	============================================= -->

	<!-- CONTENT 
	============================================= -->
	<div class="content">
		<div class="layout">
			<div class="row">
			  <div class="row-item col-3_4">
				<?php if($this->uri->segment(3) == "sbiPo"): ?>
					<!-- ================================== Bank PO ============================== -->
                   	<table border="0" cellpadding="0" cellspacing="0">
                    	  <tbody>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_ExamDetails"><div id="ctl00_ContentBody_oExamDetails" name="oExamDetails">
                    	        <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    	          <tbody>
                    	            <tr>
                    	              <td>Now SBI bank PO recruitment is easier than before. Never mind if you are a fresher; TESTfunda's bank exam preparation study material is customized for you to get that upcoming vacancy. Be it SBI or Bank of India, you've got just the right study material. Also, know everything about PO exam pattern and applying to the same below.</td>
                  	              </tr>
                    	            <tr>
                    	              <td>State Bank of India (SBI) conducts an exam for recruitment to the post of Probationary Officer (PO) for its branches across the country.</td>
                  	              </tr>
                  	            </tbody>
                  	          </table>
                  	        </div></td>
                  	      </tr>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_EligibilityName"><div id="ctl00_ContentBody_oEligibility" name="oEligibility"><a name="Eligibility" id="Eligibility">
                    	        <br/><br/>
                    	        <h3>Eligibility</h3>
                  	        </a></div>
                  	        </td>
                  	      </tr>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_EligibilityDetails"><div id="ctl00_ContentBody_oEligibilityDetails" name="oEligibilityDetails">
                    	        <table border="0" cellpadding="0" cellspacing="0">
                    	          <tbody>
                    	            <tr>
                    	              <td>1.</td>
                    	              <td>Educational Qualification</td>
                  	              </tr>
                    	            <tr>
                    	              <td>Â </td>
                    	              <td>Graduate degree in any stream from a recognized university or any equivalent qualification recognized by the Central Government.Â <br />
                    	                <br />
                    	                Final year students can also apply subject to submission of requisite proof by Sep 01, 2015.</td>
                  	              </tr>
                    	            <tr>
                    	              <td>2.</td>
                    	              <td>Age Limit</td>
                  	              </tr>
                    	            <tr>
                    	              <td>Â </td>
                    	              <td>A candidate should be between 21 - 30 years as on 01-04-2015 for the June 2014 exam.Â <br />
                    	                <br />
                    	                <strong>Relaxation of Upper age limit</strong>Â <br />
                    	                <br />
                    	                <table class="table" width="100%" cellpadding="0" cellspacing="0" border="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td width="50%">Category</td>
                    	                      <td width="50%">Age Relaxation (years)</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="50%">OBC</td>
                    	                      <td width="50%">3</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="50%">SC/ST, Ex-servicemen of military, Domiciled in the J&amp;K during the period 01/01/1980 - 31/12/1989</td>
                    	                      <td width="50%">5</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                    	                <br />
                    	                For more categories, view theÂ <a href="https://www.sbi.co.in/portal/documents/44978/143453/revised-crpd-sbipo-rectruitment-english+advertisement.pdf/65da1b01-0111-48f0-8019-7c9939e1aeab">official notification</a>.</td>
                  	              </tr>
                  	            </tbody>
                  	          </table>
                    	        <br />
                    	        <br />
                  	        </div></td>
                  	      </tr>
                    	    <tr>
                    	      <td><table cellpadding="0" cellspacing="0" border="0" width="100%">
                    	        <tbody>
                    	          <tr>
                    	            <td><div id="ctl00_ContentBody_oDetails"><a name="TestDuration&amp;Pattern(SBIPO2015)" id="TestDuration&amp;Pattern(SBIPO2015)"></a>
                    	              <h3>Test Duration &amp; Pattern (SBI PO 2015)</h3>
                    	              <div id="Test Duration &amp; Pattern (SBI PO 2015)"><br />
                    	                <strong>Preliminary Examination</strong>: Preliminary Examination consisting of Objective Tests for 100 marks will be conducted online. This test would be of 1 hour duration consisting of 3 Sections as follows:<br />
                    	                <br />
                    	                <table class="table" cellpadding="0" cellspacing="0" border="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td width="40%">Name of test</td>
                    	                      <td width="20%">No. of Questions</td>
                    	                      <td width="20%">Marks</td>
                    	                      <td width="20%">Duration</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="40%">English Language</td>
                    	                      <td width="20%">30</td>
                    	                      <td width="20%">30</td>
                    	                      <td rowspan="4" width="10%">Composite Time of 1 hour</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="40%">Quantitative Aptitude</td>
                    	                      <td width="20%">35</td>
                    	                      <td width="20%">35</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="40%">Reasoning Ability</td>
                    	                      <td width="20%">35</td>
                    	                      <td width="20%">35</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="40%">Total</td>
                    	                      <td width="20%">100</td>
                    	                      <td width="20%">100</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                    	                <br />
                    	                <strong>Main Examination</strong>: Main Examination will consist of Objective Tests for 200 marks and Descriptive Test for 50 marks. Both the Objective and Descriptive Tests will be online. Candidates will have to answer Descriptive test by typing on the computer. Immediately after completion of Objective Test, Descriptive Test will be administered.<br />
                    	                <br />
                    	                <strong>(i) Objective Test:</strong> <br />
                    	                <br />
                    	                <table class="table" cellpadding="0" cellspacing="0" border="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td width="10%">Sr.No.</td>
                    	                      <td width="35%">Section</td>
                    	                      <td width="20%">Maximum Marks</td>
                    	                      <td width="20%">Duration</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">1</td>
                    	                      <td width="30%">English Language</td>
                    	                      <td width="20%">50</td>
                    	                      <td rowspan="4" width="20%">2 hours</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">2</td>
                    	                      <td width="30%">General Awareness, Marketing and Computer Awareness</td>
                    	                      <td width="20%">50</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">3</td>
                    	                      <td width="30%">Data Analysis and Interpretations</td>
                    	                      <td width="20%">50</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">4</td>
                    	                      <td width="30%">Reasoning (High Level)</td>
                    	                      <td width="20%">50</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">Â </td>
                    	                      <td width="30%">Total</td>
                    	                      <td width="20%">200</td>
                  	                      </tr>
                    	                    <tr></tr>
                  	                    </tbody>
                  	                  </table>
                    	                <br />
                    	                The objective test is immediately followed by a descriptive test.Â <br />
                    	                <br />
                    	                <strong>(ii) Descriptive Test:Â </strong><br />
                    	                <br />
                    	                <table class="table" cellpadding="0" cellspacing="0" border="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td width="35%">Section</td>
                    	                      <td width="20%">Maximum Marks</td>
                    	                      <td width="20%">Duration</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="30%">English Language (Letter Writing and Essay)</td>
                    	                      <td width="20%">50</td>
                    	                      <td rowspan="4" width="20%">1 hour</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                  	                </div>
                    	              <br />
                    	              <br />
                    	              <a name="SelectionProcess" id="SelectionProcess"></a>
                    	              <h3>Selection Process</h3>
                    	              <div id="Selection Process">
                    	                <table border="0" cellpadding="0" cellspacing="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td>SBI PO consists of 4 successive stages:Â <br />
                    	                        <table border="0" cellpadding="0" cellspacing="0">
                    	                          <tbody>
                    	                            <tr>
                    	                              <td>i.</td>
                    	                              <td>Preliminary Examination (online).</td>
                  	                              </tr>
                    	                            <tr>
                    	                              <td>ii.</td>
                    	                              <td>Main Examination: Objective (online)and Descriptive (online) examination.</td>
                  	                              </tr>
                    	                            <tr>
                    	                              <td>iii.</td>
                    	                              <td>Group Discussion and Personal Interview of 20 and 30 marks respectively.</td>
                  	                              </tr>
                    	                            <tr>
                    	                              <td>iv.</td>
                    	                              <td>Final selection based on a total of 100 marks taken from both objective and descriptive tests and the GD - PI.</td>
                  	                              </tr>
                  	                            </tbody>
                  	                          </table></td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                  	                </div>
                  	              </div></td>
                  	            </tr>
                  	          </tbody>
                  	        </table></td>
                  	      </tr>
                  	    </tbody>
               	  </table>
               	  <!-- ================================== End Bank PO ============================== -->
                    <?php elseif($this->uri->segment(3) == "sbiSo"): ?>
                    <!-- ================================== Bank SO ============================== -->
                    
                    <p><strong>ELIGIBILITY CRITERIA</strong></p>
                    <table class="table" border="1" width="687" cellspacing="0" cellpadding="0">
                      <tbody>
                        <tr>
                          <td valign="top" width="103"><strong>Post</strong></td>
                          <td valign="top" width="66"><strong>Age Limit</strong></td>
                          <td valign="top" width="246"><strong>Essential Qualification</strong></td>
                          <td valign="top" width="272"><strong>Relevant full time post qualification experience</strong></td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Manager (Law)</td>
                          <td valign="top" width="66">35 Years</td>
                          <td valign="top" width="246">Graduation with Bachelors degree in Law</td>
                          <td valign="top" width="272">Minimum 5 years experience with reputed National or International Law firm(s) of Advocates/Solicitors</td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Manager</td>
                          <td valign="top" width="66">35 Years</td>
                          <td valign="top" width="246"><ul>
                            <li>M.A. in Economics (minimum 55%) with Economics and M.Phil in related area/ MBA (Finance) from a reputed institution.</li>
                            <li>Should hold a proficiency certificate in MS-Office</li>
                            <li>The candidate should have to their credit published work / research papers in the area of finance and banking</li>
                          </ul></td>
                          <td valign="top" width="272">5 years&rsquo; work experience as economist /analyst in a reputed organisation. Those with research experience in the area of finance and banking with application of econometric techniques are also eligible to apply.</td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Deputy Manager (Economist)</td>
                          <td valign="top" width="66">30 Years</td>
                          <td valign="top" width="246"><ul>
                            <li>M.A. in Economics (minimum 55%) with Econometrics / Mathematical Economics and M.Phil in related area from a reputed institution.</li>
                            <li>Should hold a proficiency certificate in MS-Office.</li>
                          </ul></td>
                          <td valign="top" width="272">Minimum 1 year work experience as economist / analyst in a Financial Institution / Government / reputed institutions.</td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Deputy Manager (Security)</td>
                          <td valign="top" width="66">35 Years</td>
                          <td valign="top" width="246"></td>
                          <td valign="top" width="272">An officer with minimum 5 years commissioned service in Army / Navy / Air Force or a (Security) Police Officer not below the rank of ASP / Dy. SP with minimum 5 years service in that Rank or officer of identical rank with minimum 5 years service in para-military services.Officers from the fighting arms will be given preference.</td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Assistant Manager (Systems)</td>
                          <td valign="top" width="66">30 Years</td>
                          <td valign="top" width="246">First Class B.E. (Computers), B.Tech (Computer Engineering), M.Sc. (Computer Science) or MCAs from Govt. recognized reputed institutes. Govt. recognized reputed institutes work experience may also apply.</td>
                          <td valign="top" width="272">Experience in computer programming in a reputed organisation, where available, would be desirable.</td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Assistant Manager(Law)</td>
                          <td valign="top" width="66">30 Years</td>
                          <td valign="top" width="246">Graduate with a degree in Law from a recognized university or a Law Graduate who has passed a 5 years integrated law course.</td>
                          <td valign="top" width="272">The candidate should be enrolled as an Advocate with the Bar Council and should have
                            <ol>
                              <li>minimum 2 years active practice as an Advocate OR</li>
                              <li>2 years combined active experience of practice as an Advocate and in the Legal Department of a Central/State Government or Scheduled Bank/Public SectorÂ  undertaking/Organisation OR</li>
                              <li>2 years experience as a member of State Judicial Service.</li>
                            </ol></td>
                        </tr>
                        <tr>
                          <td valign="top" width="103">Permanent Part Time Medical OfficerÂ  (PPMO)</td>
                          <td valign="top" width="66">35 Years</td>
                          <td valign="top" width="246">MBBS degree from a recognized university</td>
                          <td valign="top" width="272">Minimum 5 years experience as a General Practitioner as on the date of eligibilityreckoned from the date of registration withThe Medical Council of India (MCI). (Experience gained during internshipwill not be counted for eligibility)</td>
                        </tr>
                      </tbody>
                    </table>
                    <p><strong>Relaxation of Upper age limit</strong></p>
                    <ul>
                      <li>SC/ST candidates by 5 years; SC/ST â€“ PWD candidates by 15 years.</li>
                      <li>OBC candidates by 3 years; OBC â€“ PWD candidates by 13 years; Gen â€“ PWD candidates by 10 years.</li>
                      <li>Ex-servicemen, Commissioned officers including those ECOs/SSCOs who have rendered at least 5 years military service and have been released on completion of assignment (including those whose assignment is due to be completed within one year from the last date of receipt of application) otherwise than by way of dismissal or discharge on account of misconduct or inefficiency or physical disability attributable to military service or on invalidment.</li>
                    </ul>
                    <p>by 5 years for selection through written test and interview</p>
                    <p>by 3 years plus period of service in Armed Forces for the selection through interview only</p>
                    <p>By 5 years for the posts of Dy. Manager (security) subject to maximum age limit of 40 years.</p>
                    <ul>
                      <li>Persons domiciled in the state of Jammu &amp; Kashmir during the period from 01.01.1980 to 31.12.1989 by 5 years. No other relaxation in upper age limit is available.</li>
                    </ul>
                    <!-- ================================== End Bank SO ============================== -->
                    <!-- ================================== End Bank SO ============================== -->
                    
                    <?php elseif($this->uri->segment(3) == "sbiClerk"): ?>
                    <!-- ================================== Bank sbiClerk ============================== -->
                   	<p>Welcome to the page of SBI Recruitment 2015. The page is exclusively to list all the latest jobsÂ vacanciesÂ announced by State Bank of India.</p>
                    	<p><strong>A little about SBI</strong>: The State Bank of India is one of the apex banks of the country that aims at providing non profit service to India through the aid of Community Banking Service. Since, 1973, the bank has been actively involved in bring about radical developments in the financial sector of the economy. At the present date the bank accounts for having more than US$ 360 billion in asset form and carries out its operations on a global level. Formed with the collaboration of many ancient banks such as Imperial Bank of India, etc., the SBI is regarded as the oldest bank in the Indian Subcontinent. As this page is not about the introduction of SBI but for SBI recruitment projects, jobs, vacancies and making career in state bank of India as a probationary officers or clerks. So we&rsquo;ll here only talk about the SBI latest recruitment. So lets discuss aboutÂ <strong><em>SBI RecruitmentÂ </em>2015Â </strong>in detail. At the end, you can find open positions in SBI.</p>
                    	<p><strong>SBI Recruitment 2015 for the 2393 posts of Probationary Officer (PO):Â </strong>State Bank of India (SBI) Mumbai to make the required staffing of the applicants had announced to provide the joining letters. This joining will be substantial only for the 2393 posts of Probationary Officer (PO) and the eligibility norms are discussed below:</p>
                    	<p><strong>AgeÂ Limit</strong>:Â Candidates are mentioned to have the age not below 21 years and not above the 30 years. The cut â€“ off date for deciding the age for the post is provided to be considered as 1stÂ April 2015.</p>
                    	<p><strong>Educational Criterion Set</strong>:Â Candidates must have Bachelor Degree orÂ GraduationÂ degree under the possession in any stream. Applicants with theÂ qualificationÂ comparable to it are also equally appreciable.</p>
                    	<p><strong>Fees Schedule</strong>: Candidates of the category GEN and OBC will be required to pay Rs. 600 and for ST, SC, and PWD category applicants the amount is Rs. 100. Fee has to be pay only through online mode.</p>
                    	<p><strong>Selection Method</strong>: Candidates will be granted with the services on giving the eye-catching appearance in written exam as well as in the personalÂ interview.</p>
                    	<p><strong>Scheme Submit the Application Form</strong>:Â The request for the registration will be countable only at the official website of the State Bank of India (SBI). Applicants must also retain the print out of the application.</p>
               	  <!-- ================================== End Bank sbiClerk ============================== -->
					
                    <?php elseif($this->uri->segment(3) == "rbiClark"): ?>
                    <!-- ================================== Bank rbiClark ============================== -->
                    
                    <div>
                      <span lang="EN-US" xml:lang="EN-US">Welcome to ejobshubÂ <span id="IL_AD4">reserve bank of India</span>Â (<em>RBI</em>)<em>Â syllabus2015</em>Â page. dear viewers on this page we are conscious about R<em>BI PO, Grade B &amp; assistant examÂ <span id="IL_AD3">syllabus</span>Â 2015</em>Â withÂ <em>free solved<span id="IL_AD1">question paper</span></em>.</span></div>
                    <a name="more" id="more"></a><br />
                    <br />
                    <div><span lang="EN-US" xml:lang="EN-US">Every yearÂ reserve bank of IndiaÂ (RBI) conducts exams for Probationary Officer (PO), grade B and assistant posts. These posts are becomes most reputed and valuable posts in RBI and other banks also. Peoples and bank other staff have most respect for these posts.</span></div>
                    <div>
                      <br />
                </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Dear viewers if you wants to make career inÂ reserve bank of Indiaas PO, assistant or on grade B posts, it is not an easy task becauseÂ reserve bank of IndiaÂ each exam and process of recruitment is very tuff.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">If you want to crackÂ reserve bank of IndiaÂ exam then you must need a good andÂ <span id="IL_AD5">superior</span>Â examÂ syllabusÂ whichÂ <span id="IL_AD2">can help</span>Â you in exam. Good talent and knowledge of banking sector exam will also play an effective role when you will go to crack RBI exam. Competition are very high in RBI each exam because most of Indian wants to make their career along withÂ reserve bank of India.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">So we are advised you open your eyes and fresh your mind when you start to write in RBI exam. We are telling you if you are prepare to yourself according toÂ <em>examÂ syllabusÂ </em>then no difficulty will come in front of you. We are advised you please follow only basic steps of exam.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">AÂ syllabusÂ of any exam is open a way for you, that is tell you how you can prepare to yourself if short time also. Every time we have your need in our mind. For your need we create this page which is providing you details aboutÂ <em>RBIÂ SyllabusÂ 2015</em>.</span></div>
                    <div><br />
                    </div>
                    <div>
                      <h3><strong><span lang="EN-US" xml:lang="EN-US">RBI Grade B Exam Pattern (Phase I) 2015:</span></strong></h3>
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US"><br />
                    </span></strong></div>
                    <table border="1" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td width="90"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">S. No.</span></strong></div></td>
                          <td width="150"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Subjects</span></strong></div></td>
                          <td width="81"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">No. of Questions</span></strong></div></td>
                          <td width="115"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Marks</span></strong></div></td>
                          <td width="115"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Exam Duration</span></strong></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">1.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">General Awareness</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">80</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">80</span></div></td>
                          <td rowspan="5" width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">130 Minutes</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">2.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">English Language</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">3.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">Quantitative Aptitude</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">4.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">Reasoning</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">60</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">60</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Total</span></strong></div></td>
                          <td width="150"><div align="center"><br />
                          </div></td>
                          <td width="81"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                          <td width="115"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                        </tr>
                      </tbody>
                    </table>
                    <div><br />
                    </div>
                    <div><br />
                    </div>
                    <div>
                      <h4><strong><span lang="EN-US" xml:lang="EN-US">RBI Grade B Exam Pattern (Phase II) 2015:</span></strong></h4>
                    </div>
                    <table border="1" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td width="107"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">S. No.</span></strong></div></td>
                          <td width="178"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Subjects</span></strong></div></td>
                          <td width="137"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Marks</span></strong></div></td>
                          <td width="137"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Exam Duration</span></strong></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><span lang="EN-US" xml:lang="EN-US">1.</span></div></td>
                          <td width="178"><div align="center"><span lang="EN-US" xml:lang="EN-US">English</span></div></td>
                          <td width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">100</span></div></td>
                          <td rowspan="4" width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">180 Minutes</span></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><span lang="EN-US" xml:lang="EN-US">2.</span></div></td>
                          <td width="178"><div align="center"><span lang="EN-US" xml:lang="EN-US">Economic and Social Issues</span></div></td>
                          <td width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">100</span></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><span lang="EN-US" xml:lang="EN-US">3.</span></div></td>
                          <td width="178"><div align="center"><span lang="EN-US" xml:lang="EN-US">Finance and Management</span></div></td>
                          <td width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">100</span></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Total</span></strong></div></td>
                          <td width="178"><div align="center"><br />
                          </div></td>
                          <td width="137"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">300</span></strong></div></td>
                        </tr>
                      </tbody>
                    </table>
                    <div><br />
                    </div>
                    <div><br />
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US">RBI Clerk &amp; Assistant ExamÂ SyllabusÂ (Phase I) â€“</span></strong></div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US"><br />
                    </span></strong></div>
                    <table border="1" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td width="135"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Subject</span></strong></div></td>
                          <td width="104"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Questions</span></strong></div></td>
                          <td valign="top" width="99"><div align="center"><br />
                          </div>
                            <div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Marks</span></strong></div></td>
                          <td width="106"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Exam uration</span></strong></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">Reasoning</span></div></td>
                          <td rowspan="5" width="104"><div align="center"><br />
                          </div>
                            <div align="center"><span lang="EN-US" xml:lang="EN-US">200</span></div></td>
                          <td rowspan="5" valign="top" width="99"><div align="center"><br />
                          </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div><br />
                            </div>
                            <div><span lang="EN-US" xml:lang="EN-US">200</span></div></td>
                          <td rowspan="6" width="106"><div><span lang="EN-US" xml:lang="EN-US">120 Minutes</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">Numerical Ability</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">English Language</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">General Awareness (GA)</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">Computer Knowledge</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Total</span></strong></div></td>
                          <td width="104"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                          <td valign="top" width="99"><div align="center"><br />
                          </div>
                            <div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                        </tr>
                      </tbody>
                    </table>
                    <div><br />
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US">Phase (II)</span></strong><span lang="EN-US" xml:lang="EN-US">Â - It consists of descriptive type questions from the English.</span></div>
                    <div><br />
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US">Phase (III)</span></strong><span lang="EN-US" xml:lang="EN-US">Â â€“ in phase third the bank will conduct below given sections -</span></div>
                    <div></div>
                    <ul>
                      <li>Group Discussion,</li>
                      <li>Mock Test</li>
                      <li>Panel Interview</li>
                      <li>Ability Test etc.</li>
                    </ul>
                    <div><span lang="EN-US" xml:lang="EN-US">As you know in every written exam,Â syllabusÂ and exam pattern always play a key role if you want to crack any competition exam. Selection criteria other phase are start after written exam performance so take it seriously.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Below we are also providing you some useful points for your written exam. So please look these points once time before appear in exam.</span></div>
                    
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Dear viewers if you want good preparation for RBI PO, Clerk and assistant written exam 2015, you must need a goodÂ syllabus. Above on this page our team has been cleared theÂ <em>RBI PO, Clerk and assistant examÂ syllabus</em>Â in efficient andÂ <span id="IL_AD7">better way</span>, believe on us this exam syllabus will help you very much.</span></div>
                    <div><br />
                    </div>
                    
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Related toÂ <em>RBIÂ syllabusÂ 2015</em>Â for PO, Clerk, Assistant exam, if you have any difficulty or suggestion for us then you can leave a comment for us with the help of below given comment box.</span></div>
                  <!-- ================================== End Bank rbiClark ============================== -->
					
                    <?php elseif($this->uri->segment(3) == "rbiManager"): ?>
                    <!-- ================================== Bank rbiManager ============================== -->
                    
                                        <div>
                      <span lang="EN-US" xml:lang="EN-US">Welcome to ejobshubÂ <span id="IL_AD4">reserve bank of India</span>Â (<em>RBI</em>)<em>Â syllabus2015</em>Â page. dear viewers on this page we are conscious about R<em>BI PO, Grade B &amp; assistant examÂ <span id="IL_AD3">syllabus</span>Â 2015</em>Â withÂ <em>free solved<span id="IL_AD1">question paper</span></em>.</span></div>
                    <a name="more" id="more"></a><br />
                    <br />
                    <div><span lang="EN-US" xml:lang="EN-US">Every yearÂ reserve bank of IndiaÂ (RBI) conducts exams for Probationary Officer (PO), grade B and assistant posts. These posts are becomes most reputed and valuable posts in RBI and other banks also. Peoples and bank other staff have most respect for these posts.</span></div>
                    <div>
                      <br />
                </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Dear viewers if you wants to make career inÂ reserve bank of Indiaas PO, assistant or on grade B posts, it is not an easy task becauseÂ reserve bank of IndiaÂ each exam and process of recruitment is very tuff.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">If you want to crackÂ reserve bank of IndiaÂ exam then you must need a good andÂ <span id="IL_AD5">superior</span>Â examÂ syllabusÂ whichÂ <span id="IL_AD2">can help</span>Â you in exam. Good talent and knowledge of banking sector exam will also play an effective role when you will go to crack RBI exam. Competition are very high in RBI each exam because most of Indian wants to make their career along withÂ reserve bank of India.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">So we are advised you open your eyes and fresh your mind when you start to write in RBI exam. We are telling you if you are prepare to yourself according toÂ <em>examÂ syllabusÂ </em>then no difficulty will come in front of you. We are advised you please follow only basic steps of exam.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">AÂ syllabusÂ of any exam is open a way for you, that is tell you how you can prepare to yourself if short time also. Every time we have your need in our mind. For your need we create this page which is providing you details aboutÂ <em>RBIÂ SyllabusÂ 2015</em>.</span></div>
                    <div><br />
                    </div>
                    <div>
                      <h3><strong><span lang="EN-US" xml:lang="EN-US">RBI Grade B Exam Pattern (Phase I) 2015:</span></strong></h3>
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US"><br />
                    </span></strong></div>
                    <table border="1" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td width="90"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">S. No.</span></strong></div></td>
                          <td width="150"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Subjects</span></strong></div></td>
                          <td width="81"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">No. of Questions</span></strong></div></td>
                          <td width="115"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Marks</span></strong></div></td>
                          <td width="115"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Exam Duration</span></strong></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">1.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">General Awareness</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">80</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">80</span></div></td>
                          <td rowspan="5" width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">130 Minutes</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">2.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">English Language</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">3.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">Quantitative Aptitude</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">30</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><span lang="EN-US" xml:lang="EN-US">4.</span></div></td>
                          <td width="150"><div align="center"><span lang="EN-US" xml:lang="EN-US">Reasoning</span></div></td>
                          <td width="81"><div align="center"><span lang="EN-US" xml:lang="EN-US">60</span></div></td>
                          <td width="115"><div align="center"><span lang="EN-US" xml:lang="EN-US">60</span></div></td>
                        </tr>
                        <tr>
                          <td width="90"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Total</span></strong></div></td>
                          <td width="150"><div align="center"><br />
                          </div></td>
                          <td width="81"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                          <td width="115"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                        </tr>
                      </tbody>
                    </table>
                    <div><br />
                    </div>
                    <div><br />
                    </div>
                    <div>
                      <h4><strong><span lang="EN-US" xml:lang="EN-US">RBI Grade B Exam Pattern (Phase II) 2015:</span></strong></h4>
                    </div>
                    <table border="1" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td width="107"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">S. No.</span></strong></div></td>
                          <td width="178"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Subjects</span></strong></div></td>
                          <td width="137"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Marks</span></strong></div></td>
                          <td width="137"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Exam Duration</span></strong></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><span lang="EN-US" xml:lang="EN-US">1.</span></div></td>
                          <td width="178"><div align="center"><span lang="EN-US" xml:lang="EN-US">English</span></div></td>
                          <td width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">100</span></div></td>
                          <td rowspan="4" width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">180 Minutes</span></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><span lang="EN-US" xml:lang="EN-US">2.</span></div></td>
                          <td width="178"><div align="center"><span lang="EN-US" xml:lang="EN-US">Economic and Social Issues</span></div></td>
                          <td width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">100</span></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><span lang="EN-US" xml:lang="EN-US">3.</span></div></td>
                          <td width="178"><div align="center"><span lang="EN-US" xml:lang="EN-US">Finance and Management</span></div></td>
                          <td width="137"><div align="center"><span lang="EN-US" xml:lang="EN-US">100</span></div></td>
                        </tr>
                        <tr>
                          <td width="107"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Total</span></strong></div></td>
                          <td width="178"><div align="center"><br />
                          </div></td>
                          <td width="137"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">300</span></strong></div></td>
                        </tr>
                      </tbody>
                    </table>
                    <div><br />
                    </div>
                    <div><br />
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US">RBI Clerk &amp; Assistant ExamÂ SyllabusÂ (Phase I) â€“</span></strong></div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US"><br />
                    </span></strong></div>
                    <table border="1" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td width="135"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Subject</span></strong></div></td>
                          <td width="104"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Questions</span></strong></div></td>
                          <td valign="top" width="99"><div align="center"><br />
                          </div>
                            <div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Marks</span></strong></div></td>
                          <td width="106"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Exam uration</span></strong></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">Reasoning</span></div></td>
                          <td rowspan="5" width="104"><div align="center"><br />
                          </div>
                            <div align="center"><span lang="EN-US" xml:lang="EN-US">200</span></div></td>
                          <td rowspan="5" valign="top" width="99"><div align="center"><br />
                          </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div align="center"><br />
                            </div>
                            <div><br />
                            </div>
                            <div><span lang="EN-US" xml:lang="EN-US">200</span></div></td>
                          <td rowspan="6" width="106"><div><span lang="EN-US" xml:lang="EN-US">120 Minutes</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">Numerical Ability</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">English Language</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">General Awareness (GA)</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><span lang="EN-US" xml:lang="EN-US">Computer Knowledge</span></div></td>
                        </tr>
                        <tr>
                          <td width="135"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">Total</span></strong></div></td>
                          <td width="104"><div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                          <td valign="top" width="99"><div align="center"><br />
                          </div>
                            <div align="center"><strong><span lang="EN-US" xml:lang="EN-US">200</span></strong></div></td>
                        </tr>
                      </tbody>
                    </table>
                    <div><br />
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US">Phase (II)</span></strong><span lang="EN-US" xml:lang="EN-US">Â - It consists of descriptive type questions from the English.</span></div>
                    <div><br />
                    </div>
                    <div><strong><span lang="EN-US" xml:lang="EN-US">Phase (III)</span></strong><span lang="EN-US" xml:lang="EN-US">Â â€“ in phase third the bank will conduct below given sections -</span></div>
                    <div></div>
                    <ul>
                      <li>Group Discussion,</li>
                      <li>Mock Test</li>
                      <li>Panel Interview</li>
                      <li>Ability Test etc.</li>
                    </ul>
                    <div><span lang="EN-US" xml:lang="EN-US">As you know in every written exam,Â syllabusÂ and exam pattern always play a key role if you want to crack any competition exam. Selection criteria other phase are start after written exam performance so take it seriously.</span></div>
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Below we are also providing you some useful points for your written exam. So please look these points once time before appear in exam.</span></div>
                    
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Dear viewers if you want good preparation for RBI PO, Clerk and assistant written exam 2015, you must need a goodÂ syllabus. Above on this page our team has been cleared theÂ <em>RBI PO, Clerk and assistant examÂ syllabus</em>Â in efficient andÂ <span id="IL_AD7">better way</span>, believe on us this exam syllabus will help you very much.</span></div>
                    <div><br />
                    </div>
                    
                    <div><br />
                    </div>
                    <div><span lang="EN-US" xml:lang="EN-US">Related toÂ <em>RBIÂ syllabusÂ 2015</em>Â for PO, Clerk, Assistant exam, if you have any difficulty or suggestion for us then you can leave a comment for us with the help of below given comment box.</span></div>
                    
					<!-- ================================== End Bank rbiManager ============================== -->
					
                    <?php elseif($this->uri->segment(3) == "ibpsPo"): ?>
                    <!-- ================================== Bank ibpsPo ============================== -->
                   	<table border="0" cellpadding="0" cellspacing="0">
                    	  <tbody>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_ExamName"><div id="ctl00_ContentBody_oExamName" name="oExamName"><a name="AboutIBPSCWE(PO)" id="AboutIBPSCWE(PO)">
                    	        <div>About IBPS(PO)</div>
                  	        </a></div>
                    	        <a name="AboutIBPSCWE(PO)" id="AboutIBPSCWE(PO)"></a></td>
                  	      </tr>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_ExamDetails2"><div id="ctl00_ContentBody_oExamDetails2" name="oExamDetails">
                    	        <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    	          <tbody>
                    	            <tr>
                    	              <td>â€¢</td>
                    	              <td>This is the exam held for recruitment to nationalized banks in India for jobs of Probationary Officer(PO). Find information regarding paper pattern, eligibility, etc. and crack it with the right coaching from TESTfunda.Â <br />
                    	                <table width="100%" border="0" cellpadding="0" cellspacing="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td>The Institute of Banking Personnel Selection (IBPS) conducts a Common Written Examination (CWE) on behalf of 21 nationalized banks (see list below) as a pre-requisite for selection of Probationary Officers.</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table></td>
                  	              </tr>
                    	            <tr>
                    	              <td>â€¢</td>
                    	              <td>IBPS is only the body conducting the written test. The vacancies in individual banks as well as the group discussion and personal interview process are managed by each participating bank separately.</td>
                  	              </tr>
                  	            </tbody>
                  	          </table>
                    	        <br />
                    	        <br />
                  	        </div></td>
                  	      </tr>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_EligibilityName2"><div id="ctl00_ContentBody_oEligibility2" name="oEligibility"><a name="Eligibility" id="Eligibility2">
                    	        <H3>Eligibility</H3>
                  	        </a></div>
                    	        <a name="Eligibility" id="Eligibility2"></a></td>
                  	      </tr>
                    	    <tr>
                    	      <td id="ctl00_ContentBody_EligibilityDetails2"><div id="ctl00_ContentBody_oEligibilityDetails2" name="oEligibilityDetails">
                    	        <table border="0" cellpadding="0" cellspacing="0">
                    	          <tbody>
                    	            <tr>
                    	              <td>1.</td>
                    	              <td>Nationality</td>
                  	              </tr>
                    	            <tr>
                    	              <td>Â </td>
                    	              <td>A candidate must be one of the following:</td>
                  	              </tr>
                    	            <tr>
                    	              <td colspan="2"><table border="0" cellpadding="0" cellspacing="0">
                    	                <tbody>
                    	                  <tr>
                    	                    <td>â€¢</td>
                    	                    <td>A citizen of India</td>
                  	                    </tr>
                    	                  <tr>
                    	                    <td>â€¢</td>
                    	                    <td>A subject of Nepal or Bhutan</td>
                  	                    </tr>
                    	                  <tr>
                    	                    <td>â€¢</td>
                    	                    <td>A Tibetan refugee who came over to India before 01/01/1962 with the intention of permanently settling in India</td>
                  	                    </tr>
                    	                  <tr>
                    	                    <td>â€¢</td>
                    	                    <td>A person of Indian origin who has migrated from other countries (detailed list of countries available on official website) with the intention of permanently settling in India</td>
                  	                    </tr>
                  	                  </tbody>
                  	                </table></td>
                  	              </tr>
                    	            <tr>
                    	              <td>Â </td>
                    	              <td>provided that a candidate belonging to categories above shall be a person in whose favour a certificate of eligibility has been issued by the the Indian government.</td>
                  	              </tr>
                    	            <tr>
                    	              <td>2.</td>
                    	              <td>Age Limit</td>
                  	              </tr>
                    	            <tr>
                    	              <td>Â </td>
                    	              <td>A candidate should be between 20 â€“ 30 years (both inclusive) as on 01-07-2013 for the Oct 2013 exam.Â <br />
                    	                <br />
                    	                <strong>Relaxation of upper age limit</strong>Â <br />
                    	                <br />
                    	                <table class="table" width="100%" cellpadding="0" cellspacing="0" border="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td width="50%">Category</td>
                    	                      <td width="50%">Age Relaxation (years)</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="50%">SC/ST</td>
                    	                      <td width="50%">5</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="50%">OBC</td>
                    	                      <td width="50%">3</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="50%">PWD</td>
                    	                      <td width="50%">10</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="50%">Domiciled in J&amp;K during the periodÂ <br />
                    	                        01/01/1980 - 31/12/1989</td>
                    	                      <td width="50%">5</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                    	                <br />
                    	                For more categories, visit theÂ <a target="_blank" href="http://www.ibps.in/">official website</a>.</td>
                  	              </tr>
                    	            <tr>
                    	              <td>3.</td>
                    	              <td>Educational Qualification</td>
                  	              </tr>
                    	            <tr>
                    	              <td>Â </td>
                    	              <td>A candidate must be a graduate in any discipline from a recognized University or any equivalent qualification recognized as such by the Central Government.<br />
                    	                <br /></td>
                  	              </tr>
                  	            </tbody>
                  	          </table>
                    	        <br />
                    	        <br />
                  	        </div></td>
                  	      </tr>
                    	    <tr>
                    	      <td><table cellpadding="0" cellspacing="0" border="0" width="100%">
                    	        <tbody>
                    	          <tr>
                    	            <td><div id="ctl00_ContentBody_oDetails2"><a name="TestDuration&amp;Pattern(IBPSCWEPO2014)" id="TestDuration&amp;Pattern(IBPSCWEPO2014)"></a>
                    	              <H3>Test Duration &amp; Pattern </H3>
                    	              <div id="Test Duration &amp; Pattern (IBPS CWE PO 2014)"><br />
                    	                <table class="table" cellpadding="0" cellspacing="0" border="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td width="10%">Sr.No.</td>
                    	                      <td width="35%">Name of Test</td>
                    	                      <td width="20%">No. of questions</td>
                    	                      <td width="20%">Maximum Marks</td>
                    	                      <td width="40%">Duration</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">1</td>
                    	                      <td width="30%">Reasoning</td>
                    	                      <td width="20%">50</td>
                    	                      <td width="20%">50</td>
                    	                      <td rowspan="6" width="20%">Composite time of 120 minutes</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">2</td>
                    	                      <td width="30%">English Language</td>
                    	                      <td width="20%">40</td>
                    	                      <td width="20%">40</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">3</td>
                    	                      <td width="30%">Quantitative Aptitude</td>
                    	                      <td width="20%">50</td>
                    	                      <td width="20%">50</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">4</td>
                    	                      <td width="30%">General Awareness (with special reference to Banking Industry)</td>
                    	                      <td width="20%">40</td>
                    	                      <td width="20%">40</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td width="10%">5</td>
                    	                      <td width="30%">Computer Knowledge</td>
                    	                      <td width="20%">20</td>
                    	                      <td width="20%">20</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td colspan="2" width="30%">Total</td>
                    	                      <td width="20%">200</td>
                    	                      <td width="20%">200</td>
                  	                      </tr>
                    	                    <tr>
                    	                      <td colspan="5" width="10%">Negative Marking: 1/4th of the marks deducted for every incorrect answer</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                  	                </div>
                    	              <a name="ExamFormat" id="ExamFormat"></a>
                    	              <H3>Exam Format</H3>
                    	              <div id="Exam Format">
                    	                <table border="0" cellpadding="0" cellspacing="0">
                    	                  <tbody>
                    	                    <tr>
                    	                      <td>The IBPS CWE (PO) is now held online.</td>
                  	                      </tr>
                  	                    </tbody>
                  	                  </table>
                  	                </div>
                  	              </div></td>
                  	            </tr>
                  	          </tbody>
                  	        </table></td>
                  	      </tr>
                  	    </tbody>
               	  </table>
               	  <!-- ================================== End Bank ibpsPo ============================== -->
					
                    <?php elseif($this->uri->segment(3) == "ibpsSo"): ?>
                    <!-- ================================== Bank ibpsSo ============================== -->
                    
                <table border="0" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td id="ctl00_ContentBody_ExamName2"><div id="ctl00_ContentBody_oExamName2" name="oExamName"><a name="AboutIBPSCWESO" id="AboutIBPSCWESO">
                          </a></div>
                            <a name="AboutIBPSCWESO" id="AboutIBPSCWESO"></a></td>
                        </tr>
                        <tr>
                          <td id="ctl00_ContentBody_ExamDetails3"><div id="ctl00_ContentBody_oExamDetails3" name="oExamDetails">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td>This is the exam held for recruitment to nationalized banks in India to fill vacancies for specialist officers for both Scale I and Scale II posts in Public Sector Banks. Find information about the examination regarding paper pattern, eligibility, etc. below.</td>
                                </tr>
                                <tr>
                                  <td>A Common Written Examination (CWE) is conducted by the Institute of Banking Personnel Selection (IBPS) as a pre-requisite for selection of personnel for Specialist Officers. The specialist officers are from different fields: Law, Marketing, Finance, HR, Agriculture Field Officer, Rajbhasha Adhikari and Information Technology.</td>
                                </tr>
                              </tbody>
                            </table>
                            <br />
                            <br />
                          </div></td>
                        </tr>
                        <tr>
                          <td id="ctl00_ContentBody_EligibilityName3"><div id="ctl00_ContentBody_oEligibility3" name="oEligibility"><a name="Eligibility" id="Eligibility3">
                            <h3>Eligibility</h3>
                          </a></div>
                            <a name="Eligibility" id="Eligibility3"></a></td>
                        </tr>
                        <tr>
                          <td id="ctl00_ContentBody_EligibilityDetails3"><div id="ctl00_ContentBody_oEligibilityDetails3" name="oEligibilityDetails">
                            <table class="table" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td>1.</td>
                                  <td>Nationality</td>
                                </tr>
                                <tr>
                                  <td>Â </td>
                                  <td>A candidate must be one of the following:</td>
                                </tr>
                                <tr>
                                  <td colspan="2"><table border="0" cellpadding="0" cellspacing="0">
                                    <tbody>
                                      <tr>
                                        <td>â€¢</td>
                                        <td>A citizen of India</td>
                                      </tr>
                                      <tr>
                                        <td>â€¢</td>
                                        <td>A subject of Nepal or Bhutan</td>
                                      </tr>
                                      <tr>
                                        <td>â€¢</td>
                                        <td>A Tibetan refugee who came over to India before 01/01/1962 with the intention of permanently settling in India</td>
                                      </tr>
                                      <tr>
                                        <td>â€¢</td>
                                        <td>A person of Indian origin who has migrated from Pakistan, Burma, Sri Lanka, East African countries of Kenya, Uganda, the United Republic of Tanzania (formerly Tanganyika and Zanzibar), Zambia, Malawi, Zaire, Ethiopia and Vietnam with the intention of permanently settling in India,</td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                                </tr>
                                <tr>
                                  <td>Â </td>
                                  <td>provided that a candidate belonging to categories above shall be a person in whose favour a certificate of eligibility has been issued by the the Indian government.</td>
                                </tr>
                                <tr>
                                  <td>2.</td>
                                  <td>Age Limit</td>
                                </tr>
                                <tr>
                                  <td>Â </td>
                                  <td>For posts in Scale I: a candidate must have been born not earlier than 02.11.1983 and not later than 01.11.1993 (both dates inclusive)Â <br />
                                    For posts in Scale II: a candidate must have been born not earlier than 02.11.1978 and not later than 01.11.1993 (both dates inclusive)Â <br />
                                    <br />
                                    <strong>Relaxation of upper age limit</strong>Â <br />
                                    <br />
                                    <table class="table" width="100%" cellpadding="0" cellspacing="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td width="50%">Category</td>
                                          <td width="50%">Age Relaxation (years)</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">SC/ST</td>
                                          <td width="50%">5</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">OBC</td>
                                          <td width="50%">3</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">PWD</td>
                                          <td width="50%">10</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">Ex-Servicemen, Commissioned Officers including Emergency Commissioned Officers (ECOs)/ Short Service Commissioned Officers (SSCOs) who have rendered at least 5 years military service and have been released on completion of assignment (including those whose assignment is due to be completed within one year from the last date of receipt of application) otherwise than by way of dismissal or discharge on account of misconduct or inefficiency or physical disability attributable to military service or invalidment</td>
                                          <td width="50%">5</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">Persons ordinarily domiciled in the Kashmir Division of the State of Jammu &amp; Kashmir during the period 1-1-80 to 31-12-89</td>
                                          <td width="50%">5</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">Persons affected by 1984 riots</td>
                                          <td width="50%">5</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <br />
                                    For more categories, visit theÂ <a target="_blank" href="http://www.ibps.in/">official website</a>.</td>
                                </tr>
                                <tr>
                                  <td>3.</td>
                                  <td>Educational Qualification</td>
                                </tr>
                                <tr>
                                  <td colspan="2">
                                  <table class="table" cellpadding="0" cellspacing="0" border="0">
                                    <tbody>
                                      <tr>
                                        <td width="10%">Post Code</td>
                                        <td width="10%">Name of the Post</td>
                                        <td width="10%">Age</td>
                                        <td width="35%">Educational Qualifications (from a University/ Institution/ Board recognised by Govt. Of India/ approved by Govt. Regulatory Bodies)</td>
                                        <td width="35%">Post Qualification Minimum Work Experience</td>
                                      </tr>
                                      <tr>
                                        <td>01</td>
                                        <td>I.T. Officer (Scale-I)</td>
                                        <td>Min- 20 Years Max-30 Years</td>
                                        <td>a) 4 year Engineering Degree in Computer Science/ Computer Applications/ Information Technology/ Electronics/ Electronics &amp; Telecommunications/ Electronics &amp; Communication/ Electronics &amp; Instrumentation OR b) Post Graduate Degree in Electronics/ Electronics &amp; Tele Communication/ Electronics &amp; Communication/ Electronics &amp; Instrumentation/ Computer Science/ Information Technology/ Computer Applications OR Graduate having passed DOEACC &lsquo;B&rsquo; level</td>
                                        <td rowspan="6">-</td>
                                      </tr>
                                      <tr>
                                        <td>02</td>
                                        <td>Agricultural Field Officer (Scale I)</td>
                                        <td>Min- 20 Years Max-30 Years</td>
                                        <td>4 year Degree (graduation) in Agriculture/ Horticulture/Animal Husbandry/ Veterinary Science/ Dairy Science/ Agri. Engineering/ Fishery Science/ Pisciculture/ Agri Marketing &amp; Cooperation/ Co-operation &amp; Banking/ Agro-Forestry</td>
                                      </tr>
                                      <tr>
                                        <td>03</td>
                                        <td>Rajbhasha Adhikari (Scale I)</td>
                                        <td>Min- 20 Years Max-30 Years</td>
                                        <td>Post Graduate Degree in Hindi with English as a subject at the degree (graduation) level OR Post graduate degree in Sanskrit with English and Hindi as subjects at the degree (graduation) level.</td>
                                      </tr>
                                      <tr>
                                        <td>04</td>
                                        <td>Law Officer (Scale I)</td>
                                        <td>Min- 20 Years Max-30 Years</td>
                                        <td>A Bachelor Degree in Law (LLB) and enrolled as an advocate with Bar Council</td>
                                      </tr>
                                      <tr>
                                        <td>05</td>
                                        <td>HR/Personnel Officer (Scale I)</td>
                                        <td>Min- 20 years Max- 30 years</td>
                                        <td>Graduate and Full time Post Graduate degree or Full time Post Graduate diploma in Personnel Management / Industrial Relations/ HR/Social Work / Labour Law.*</td>
                                      </tr>
                                      <tr>
                                        <td>06</td>
                                        <td>Marketing Officer (Scale I)</td>
                                        <td>Min- 20 years Max- 30 years</td>
                                        <td>Graduate and Full time MBA (Marketing) / Full time 2 years PGDBA / PGDBM with specialization in Marketing *</td>
                                      </tr>
                                      <tr>
                                        <td>07</td>
                                        <td>I.T. Officer (Scale-II)</td>
                                        <td>Min- 20 Years Max-35 Years</td>
                                        <td>4 year Engineering Degree in Computer Science/ Computer Applications/ Information Technology/ Electronics/ Electronics &amp; Telecommunications/ Electronics &amp; Communication/ Electronics &amp; Instrumentation OR Post Graduate Degree in Electronics/ Electronics &amp; Tele Communication/ Electronics &amp; Communication/ Electronics &amp; Instrumentation/ Computer Science/ Information Technology/ Computer Applications OR Graduate having passed DOEACC &lsquo;B&rsquo; level</td>
                                        <td>2 years in IT field</td>
                                      </tr>
                                      <tr>
                                        <td>08</td>
                                        <td>Law Officer (Scale II)</td>
                                        <td>Min- 20 Years Max-35 Years</td>
                                        <td>A Bachelor Degree in Law (LLB)</td>
                                        <td>Enrolled as an advocate with Bar Council and 3 years experience of practice at Bar or Judicial service and/or 2 years as a Law Officer in the Legal Dept. of a Scheduled Commercial Bank or the Central/State Government or of a Public Sector Undertaking andcandidates should produce a certificate of having the requisite post qualification work experience from the Court/ Bar council/ organisation.</td>
                                      </tr>
                                      <tr>
                                        <td>09</td>
                                        <td>Chartered Accountant (Scale II)</td>
                                        <td>Min- 20 Years Max-35 Years</td>
                                        <td>Passed final examination for Chartered Accountants</td>
                                        <td>-</td>
                                      </tr>
                                      <tr>
                                        <td>10</td>
                                        <td>Manager Credit (Scale II)/ Finance Executive (Scale II)</td>
                                        <td>Min- 20 Years Max-35 Years</td>
                                        <td>Graduate and CFA/ ICWA/ Full time MBA/ Full time PGDBM (Finance) *</td>
                                        <td>2 years in the area of Credit Appraisal of big/ medium industrial projects in Scheduled Commercial Banks</td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                                </tr>
                              </tbody>
                            </table>
                            <br />
                            <br />
                          </div></td>
                        </tr>
                        <tr>
                          <td><table cellpadding="0" cellspacing="0" border="0" width="100%">
                            <tbody>
                              <tr>
                                <td><div id="ctl00_ContentBody_oDetails3"><a name="TestDuration&amp;Pattern" id="TestDuration&amp;Pattern"></a>
                                  <h3>Test Duration &amp; Pattern</h3>
                                  <div id="Test Duration &amp; Pattern"><br />
                                    The structure of the Online CWE will be as follows:<br />
                                    Law Officer- Scale I &amp; II &amp; Rajbhasha Adhikari Scale IÂ <br />
                                    <br />
                                    <table class="table" cellpadding="0" cellspacing="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td width="10%">Sr.No.</td>
                                          <td width="35%">Name of Test</td>
                                          <td width="20%">No. of questions</td>
                                          <td width="20%">Maximum Marks</td>
                                          <td width="40%">Duration</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">1</td>
                                          <td width="30%">Reasoning</td>
                                          <td width="20%">50</td>
                                          <td width="20%">50</td>
                                          <td rowspan="6" width="20%">Composite time of 120 minutes</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">2</td>
                                          <td width="30%">English Language</td>
                                          <td width="20%">50</td>
                                          <td width="20%">25</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">3</td>
                                          <td width="30%">General Awareness with special reference to Banking Industry</td>
                                          <td width="20%">50</td>
                                          <td width="20%">50</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">4</td>
                                          <td width="30%">Professional Knowledge</td>
                                          <td width="20%">50</td>
                                          <td width="20%">75</td>
                                        </tr>
                                        <tr>
                                          <td colspan="2" width="30%">Total</td>
                                          <td width="20%">200</td>
                                          <td width="20%">200</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <br />
                                    IT Officer Scales I &amp; II, Agriculture Field Officer Scale I, HR/ Personnel Officer Scale I, Marketing Officer Scale I, Chartered Accountants Scale-II &amp; Manager Credit / Finance Executive Scale-IIÂ <br />
                                    <br />
                                    <table class="table" cellpadding="0" cellspacing="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td width="10%">Sr.No.</td>
                                          <td width="35%">Name of Test</td>
                                          <td width="20%">No. of questions</td>
                                          <td width="20%">Maximum Marks</td>
                                          <td width="40%">Duration</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">1</td>
                                          <td width="30%">Reasoning</td>
                                          <td width="20%">50</td>
                                          <td width="20%">50</td>
                                          <td rowspan="6" width="20%">Composite time of 120 minutes</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">2</td>
                                          <td width="30%">English Language</td>
                                          <td width="20%">50</td>
                                          <td width="20%">25</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">3</td>
                                          <td width="30%">Quantitative Aptitude</td>
                                          <td width="20%">50</td>
                                          <td width="20%">50</td>
                                        </tr>
                                        <tr>
                                          <td width="10%">4</td>
                                          <td width="30%">Professional Knowledge</td>
                                          <td width="20%">50</td>
                                          <td width="20%">75</td>
                                        </tr>
                                        <tr>
                                          <td colspan="2" width="30%">Total</td>
                                          <td width="20%">200</td>
                                          <td width="20%">200</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                                  <a name="SelectionProcess" id="SelectionProcess2"></a>
                                  <h3>Selection Process</h3>
                                  <div id="Selection Process2">
                                    <table class="table" border="0" cellpadding="0" cellspacing="0">
                                      <tbody>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Online Test: IBPS CWE SO is an objective type online test.</td>
                                        </tr>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Interview: You must clear sectional and overall cut-offs in the written test to qualify for interview.These cut-offs are specified separately for each exam held. Interview is a common interview coordinated by IBPS.</td>
                                        </tr>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Order of preference for banks will be obtained from successful candidates who clear both written test and interview.</td>
                                        </tr>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Final Selection: Based on the marks obtained as the order of preference of banks, a successful candidate will receive a call for appointment from an individual Bank.</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <br />
                                  </div>
                                </div></td>
                              </tr>
                            </tbody>
                          </table></td>
                        </tr>
                      </tbody>
                  </table>
                <!-- ================================== End Bank ibpsSo ============================== -->
					
                  <?php elseif($this->uri->segment(3) == "sscLdc"): ?>
                  <!-- ================================== Bank sscLdc ============================== -->
                    
                <p>TheÂ <span id="IL_AD6">Staff Selection Commission</span>Â (SSC) has recently notified through an official notification published at website for the recruitment of eligible candidates in the post available underÂ Group CÂ of Lower Division Grade. Eligible and interested candidates should fill theirÂ <span id="IL_AD8">application</span>Â forms in prescribed formats before the closing date mentioned i.e. 16thÂ February 2015. The applicants participating in the recruitment should qualify the Lower Division Grade Limited Departmental Competitive Examination -2015 scheduled to be held on 5thÂ April 2015. To get more details on the mentioned recruitment, applicants should either download official notification releasedÂ <span id="IL_AD9">online at</span>Â website or follow the information as given here below.</p>
                  
                  <p><strong>Details of SSC Lower Division Grade RecruitmentÂ Application FormÂ 2015-</strong></p>
                  <p><strong>Name of Post:</strong>Â Lower Division Grade (Group C) Staff</p>
                  <p><strong>Available Vacancy:</strong>Â as per the vacancies to be intimated to Commission by each cadre of authority participating in exam</p>
                  <p><strong>Place of Recruitment:</strong>Â All over India</p>
                  <p><strong>Income/ Pay Criteria:</strong>Â Pay Band I: Rs 5200- Rs 20200 + Grade Pay of Rs 1900</p>
                  <p><strong>More Details of SSC Lower Division Grade RecruitmentÂ Application Form-</strong></p>
                  <p><strong>Norms of Eligibility:</strong></p>
                  <p>The minimum eligibility required for participating in the mentioned recruitment is Intermediate/ Class 12thÂ passed from any recognized Boards of India or any other equivalent qualification. In addition to this, applicants must have served for at least 3 years in regular service as aÂ Group CÂ employee having Grade Pay of Rs 1800.</p>
                  
                  <p><strong>Age Criteria:</strong></p>
                  <p>The age of all candidates participating should not exceed 45 years as on 1stÂ January 2015. A minimum of 5 years relaxation will be given to candidates belonging to SC/ ST for selections in the post mentioned.</p>
                  <p><strong>Method of Selection:</strong></p>
                  <p>The applicants will have to participate and qualify in the Limited Departmental Competitive Examination held for Lower Division Grade scheduled to be held on mentioned dates at following centres of examination- New Delhi, Kolkata, Mumbai, Allahabad, Chennai, Bangalore, Guwahati, Chandigarh and Raipur respectively.</p>
                  <p><strong>Manner ofÂ Application:</strong></p>
                  <p>The completedÂ applicationÂ forms should be sent in prescribed formats along with necessary enclosures to the address as mentioned here below.</p>
                  <br />
                  <!-- ================================== End Bank sscLdc ============================== -->
					
                  <?php elseif($this->uri->segment(3) == "sscCgl"): ?>
                  <!-- ================================== Bank sscCgl ============================== -->
				  <table border="0" cellpadding="0" cellspacing="0">
                      <tbody>
                        <tr>
                          <td id="ctl00_ContentBody_ExamName3"><div id="ctl00_ContentBody_oExamName3" name="oExamName"><a name="AboutSSCCGL" id="AboutSSCCGL">
                            
                          </a></div>
                            <a name="AboutSSCCGL" id="AboutSSCCGL"></a></td>
                        </tr>
                        <tr>
                          <td id="ctl00_ContentBody_ExamDetails4"><div id="ctl00_ContentBody_oExamDetails4" name="oExamDetails">
                            <table width="100%" border="0" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td>SSC CGL 2015 is held for recruitment to government jobs in India. Get details on the syllabus, form, online application process, result and more.</td>
                                </tr>
                                <tr>
                                  <td>Staff Selection Commission(SSC) conducts the Combined Graduate Level (CGL) Examination for recruitment to Group B and Group C posts in various ministries, government departments and offices across the country.</td>
                                </tr>
                              </tbody>
                            </table>
                            <br />
                            <br />
                          </div></td>
                        </tr>
                        <tr>
                          <td id="ctl00_ContentBody_EligibilityName4"><div id="ctl00_ContentBody_oEligibility4" name="oEligibility"><a name="Eligibility" id="Eligibility4">
                            <h3>Eligibility</h3>
                          </a></div>
                            <a name="Eligibility" id="Eligibility4"></a></td>
                        </tr>
                        <tr>
                          <td id="ctl00_ContentBody_EligibilityDetails4"><div id="ctl00_ContentBody_oEligibilityDetails4" name="oEligibilityDetails">
                            <table border="0" class="table" cellpadding="0" cellspacing="0">
                              <tbody>
                                <tr>
                                  <td>1.</td>
                                  <td>Nationality</td>
                                </tr>
                                <tr>
                                  <td colspan="2">A candidate must be one of the following:</td>
                                </tr>
                                <tr>
                                  <td colspan="2"><table border="0" class="table" cellpadding="0" cellspacing="0">
                                    <tbody>
                                      <tr>
                                        <td>(a)</td>
                                        <td>A citizen of India.</td>
                                      </tr>
                                      <tr>
                                        <td>(b)</td>
                                        <td>A subject of Nepal or Bhutan.</td>
                                      </tr>
                                      <tr>
                                        <td>(c)</td>
                                        <td>A Tibetan refugee who came over to India before 01/01/1962 with the intention of permanently settling in India.</td>
                                      </tr>
                                      <tr>
                                        <td>(d)</td>
                                        <td>A person of Indian origin who has migrated from other countries (detailed list of countries available inÂ <a target="_blank" href="http://ssc.nic.in/notice/examnotice/final_Notice_CGLE_2015_01_05_2015.pdf">official notification</a>) with the intention of permanently settling in India.</td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                                </tr>
                                <tr>
                                  <td colspan="2">Provided that a candidate belonging to categories (b), (c) or (d) above shall be a person in whose favour a certificate of eligibility has been issued by the the Indian government.</td>
                                </tr>
                                <tr>
                                  <td>Â </td>
                                </tr>
                                <tr>
                                  <td>2.</td>
                                  <td>Age (as on 01-08-2015 for the 2015 exam)</td>
                                </tr>
                                <tr>
                                  <td colspan="2"><table class="table" border="0" cellpadding="0" cellspacing="0">
                                    <tbody>
                                      <tr>
                                        <td>Category of Posts</td>
                                        <td>Age</td>
                                      </tr>
                                      <tr>
                                        <td>Inspector of Income Tax/ Central Excise/ Preventive Officer/ Examiner/ Posts/ CBN (Compiler), Assistant Enforcement Officer, Divisional Accountant, Auditor, UDC, Tax Assistant, Junior Accountant and Accountant, Sub-inspector(CBN)</td>
                                        <td>Between 18 - 27 years (Candidate should not have been born earlier than 02/08/1988 and later than 01/08/1997)</td>
                                      </tr>
                                      <tr>
                                        <td>Statistical Investigator Grade II</td>
                                        <td>Not more than 32 years ( Candidate should not have been born earlier than 02/08/1983 and later than 01/08/1997)</td>
                                      </tr>
                                      <tr>
                                        <td>Assistant/ Sub-inspector in CBI</td>
                                        <td>Between 20 - 30 years (Candidate should not have been born earlier than 02/08/1985 and later than 01/08/1995)</td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                                </tr>
                                <tr>
                                  <td colspan="2"><strong>Relaxation of upper age limit</strong>Â <br />
                                    <table class="table" width="100%" cellpadding="0" cellspacing="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td width="50%">Category</td>
                                          <td width="50%">Age Relaxation (years)</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">SC/ST</td>
                                          <td width="50%">5</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">OBC</td>
                                          <td width="50%">3</td>
                                        </tr>
                                        <tr>
                                          <td width="50%">PH</td>
                                          <td width="50%">10</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                    <br />
                                    For more categories, visit theÂ <a target="_blank" href="http://ssc.nic.in/notice/examnotice/final_Notice_CGLE_2015_01_05_2015.pdf">official notification</a>.</td>
                                </tr>
                                <tr>
                                  <td>Â </td>
                                </tr>
                                <tr>
                                  <td>3.</td>
                                  <td>Educational Qualification</td>
                                </tr>
                                <tr>
                                  <td colspan="2"><table class="table">
                                    <tbody>
                                      <tr>
                                        <td colspan="2">â€¢</td>
                                        <td>For the post of Compiler:Â Bachelor's degree from any recognized university with Economics/Statistics/Mathematics as compulsory or elective subject.</td>
                                      </tr>
                                      <tr>
                                        <td colspan="2">â€¢</td>
                                        <td>For the post of Statistical Investigator Grade - II:Â Bachelor's degree in any discipline from a recognized University with:<br />
                                          Atleast 60% in Mathematics at 12th Standard level OR Statistics as one of the subjects at degree level.</td>
                                      </tr>
                                      <tr>
                                        <td colspan="2">â€¢</td>
                                        <td>For all other posts:Â Bachelor's degree in any discipline from a recognized University or any other equivalent qualification.</td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                                </tr>
                              </tbody>
                            </table>
                            <br />
                            <br />
                          </div></td>
                        </tr>
                        <tr>
                          <td><table cellpadding="0" cellspacing="0" border="0" width="100%">
                            <tbody>
                              <tr>
                                <td><div id="ctl00_ContentBody_oDetails4"><a name="TestDurationandPattern(SSCCGL2015)" id="TestDurationandPattern(SSCCGL2015)"></a>
                                  <h3>Test Duration and Pattern (SSC CGL 2015)</h3>
                                  <div id="Test Duration and Pattern (SSC CGL 2015)">
                                    <table cellpadding="0" cellspacing="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td width="20%">Tier I:</td>
                                        </tr>
                                        <tr>
                                          <td><table class="table" cellpadding="0" cellspacing="0" border="0">
                                            <tbody>
                                              <tr>
                                                <td width="35%">Subject</td>
                                                <td width="20%">No. of Questions</td>
                                                <td width="20%">Maximum Marks</td>
                                                <td width="20%">Duration (hours)</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">General Intelligence &amp; Reasoning</td>
                                                <td width="20%">50</td>
                                                <td width="20%">50</td>
                                                <td rowspan="4" width="20%">2 hours</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">General Awareness</td>
                                                <td width="20%">50</td>
                                                <td width="20%">50</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">Quantitative Aptitude</td>
                                                <td width="20%">50</td>
                                                <td width="20%">50</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">English Comprehension</td>
                                                <td width="20%">50</td>
                                                <td width="20%">50</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">Total</td>
                                                <td width="20%">200</td>
                                                <td width="20%">200</td>
                                                <td width="30%">Â </td>
                                              </tr>
                                              <tr>
                                                <td colspan="4"><em>Negative Marking: 0.25 marks for every incorrect answer</em></td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                        </tr>
                                        <tr>
                                          <td width="20%">Tier II:</td>
                                        </tr>
                                        <tr>
                                          <td><table class="table" cellpadding="0" cellspacing="0" border="0">
                                            <tbody>
                                              <tr>
                                                <td width="35%">Subject</td>
                                                <td width="15%">No. of Questions</td>
                                                <td width="10%">Maximum Marks</td>
                                                <td width="20%">Negative Marking (for every incorrect answer)</td>
                                                <td width="20%">Duration (hours)</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">Quantitative Abilities</td>
                                                <td width="20%">100</td>
                                                <td width="20%">200</td>
                                                <td width="20%">0.5</td>
                                                <td width="20%">2</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">English Language &amp; Comprehension</td>
                                                <td width="20%">100</td>
                                                <td width="20%">200</td>
                                                <td width="20%">0.25</td>
                                                <td width="20%">2</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">Statistics*</td>
                                                <td width="20%">100</td>
                                                <td width="20%">200</td>
                                                <td width="20%">0.5</td>
                                                <td width="20%">2</td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                        </tr>
                                        <tr>
                                          <td>*Only for candidates who apply for the posts of Statistical Investigator Grade- II or Compiler.</td>
                                        </tr>
                                        <tr>
                                          <td width="20%">Tier III:</td>
                                        </tr>
                                        <tr>
                                          <td>Interview:Â 100 marks (for only those posts in which it is prescribed).</td>
                                        </tr>
                                        <tr>
                                          <td>For the post of Assistant in CSS:Â Computer Proficiency Test with Word Processing, Spread Sheet and Generation of Slides modules.</td>
                                        </tr>
                                        <tr>
                                          <td>For the post of Tax Assistant:Â Data Entry Skill Test at speed of 8000 key depressions per hour.</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                                  <br />
                                  <a name="SelectionProcess" id="SelectionProcess3"></a>
                                  <h3>Selection Process</h3>
                                  <div id="Selection Process3">
                                    <table class="table" border="0" cellpadding="0" cellspacing="0">
                                      <tbody>
                                        <tr>
                                          <td colspan="2">SSC CGL is a paper based test and consists of three successive stages:-</td>
                                        </tr>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Tier I - Objective type test</td>
                                        </tr>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Tier II - Objective type test</td>
                                        </tr>
                                        <tr>
                                          <td>â€¢</td>
                                          <td>Tier III - Computer proficiency test/ skill test/ interview depending on the post.</td>
                                        </tr>
                                        <tr>
                                          <td colspan="2">Note: For selection to certain posts there are certain set standards as well as a physical test. ReferÂ <a target="_blank" href="http://ssc.nic.in/notice/examnotice/final_Notice_CGLE_2015_01_05_2015.pdf">official notificationÂ </a>for details.</td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                                  <br />
                                  <a name="Posts" id="Posts"></a>
                                  <h3>Posts</h3>
                                  <div id="Posts">
                                    <table class="table" cellpadding="0" cellspacing="0" border="0">
                                      <tbody>
                                        <tr>
                                          <td>Various posts that one can apply for through SSC CGL are classified into Group B &amp; Group C. The details are as follows:</td>
                                        </tr>
                                        <tr>
                                          <td><table cellpadding="0" cellspacing="0" border="0">
                                            <tbody>
                                              <tr>
                                                <td width="35%">Description of posts</td>
                                                <td width="20%">Classification of posts</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">A Central Civil post carrying the following grade pay :-<br />
                                                  In the scale of pay of 9300 - 34800</td>
                                                <td width="20%">Group-B</td>
                                              </tr>
                                              <tr>
                                                <td width="30%">A Central Civil post carrying the following grade pay :-<br />
                                                  In the scale of pay of 5200-20200</td>
                                                <td width="20%">Group-C</td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                        </tr>
                                      </tbody>
                                    </table>
                                  </div>
                                </div></td>
                              </tr>
                            </tbody>
                          </table></td>
                        </tr>
                      </tbody>
                </table>
                	<br />
                  <!-- ================================== End Bank sscCgl ============================== -->
                  
				  <?php elseif($this->uri->segment(3) == "nicl"): ?>
                  <!-- ================================== NICL	 ============================== -->
				  
                  <p>National Insurance Company Limited (NICL) is a state owned general insurance company in India. The company headquartered at Kolkata was established in 1906 and nationalised in 1972. It's portofolio consists of a multitude of general insurance policies, offered to a wide arena of clients encompassing different sectors of the economy. Apart from being a leading insurance provider in India, NICL also serves Nepal.
                  </p>

<h2>History</h2>
<p>After nationalisation in 1972, NICL operated as a subsidiary of General Insurance Corporation of India (GIC). NICL was spun off as a distinct company under the General Insurance Business (Nationalisation) Amendment Act in 2002. In April, 2004, NIC signed an agreement with Nainital Bank for distribution of its general insurance products through the bank's branches in Uttarakhand, Haryana and New Delhi.</p>

<h2>Company profile</h2>
<p>National Insurance Company Limited was incorporated in December 6, 1906 with its Registered office in Kolkata. Consequent to passing of the General Insurance Business Nationalisation Act in 1972, 21 Foreign and 11 Indian Companies were amalgamated with it and National became a subsidiary of General Insurance Corporation of India (GIC) which is fully owned by the Government of India. After the notification of the General Insurance Business and its India's largest gic company(Nationalisation) Amendment Act, on 7 August 2002, National has been de-linked from its holding company GIC and presently operating as an independent insurance company wholly owned by Govt of India. National Insurance Company Ltd (NIC) is one of the leading public sector insurance companies of India, carrying out non life insurance business. Headquartered in Kolkata, NIC's network of about 1000 offices, manned by more than 16,000 skilled personnel, is spread over the length and breadth of the country covering remote rural areas, townships and metropolitan cities. NIC's foreign operations are carried out from its branch offices in Nepal. Befittingly, the product ranges, of more than 200 policies offered by NIC cater to the diverse insurance requirements of its 14 million policyholders. Innovative and customised policies ensure that even specialised insurance requirements are fully taken care of. The paid-up share capital of National is â‚¹100 crores. Starting off with a premium base of â‚¹50 crores in 1974, NIC's gross direct premium income has steadily grown to about â‚¹9000 crores rupees in the financial year 2012-13. National transacts general insurance business of Fire, Marine and Miscellaneous insurance. The Company offers protection against a wide range of risks to its customers. The Company is privileged to cater its services to almost every sector or industry in the Indian Economy viz. Banking, Telecom, Aviation, Shipping, Information Technology, Power, Oil & Energy, Agronomy, Plantations, Foreign Trade, Healthcare, Tea, Automobile, Education, Environment, Space Research etc. As of 2010, NICL has a AAA rating from Indian rating agency, CRISIL, a subsidiary of Standard and Poor's Company. The gross premiums from underwriting by the company grew by 32.22% to over â‚¹6,100 crores during the Financial Year 2010-2011. And Gross Premiun grew up to 10,000 crores during the financial year 2013-2014.[9] With this, the company was ranked second among general insurance companies operating in India, behind New India Assurance, at the end of the 2014 Financial Year.[9] With about 1000 offices and 16,000 employees and agents, the company operates in all of India, and neighbouring Nepal.[1] In 2008, the company signed a deal with HCL Technologies worth almost â‚¹400 crores to outsource the companyâ€™s information technology requirements over 7 years.</p>

<h2>Products and services</h2>
<p><strong>NICL has a range of coverage policies targeting different sectors:</strong></p>

<p>Personal Insurance policies include medical insurance, accident, property and auto insurance coverage
Rural Insurance policies provide protection against natural and climatic disasters for agriculture and rural businesses
Industrial Insurance policies provide coverage for project, construction, contracts, fire, equipment loss, theft, etc.
Commercial Insurance policies provide protection against loss and damage of property during transportation, transactions, etc.</p>
                  <!-- ================================== End NICL ============================== -->
                  
                  <?php elseif($this->uri->segment(3) == "lic"): ?>
                  <!-- ================================== LIC ============================== -->
				 	<p>Life Insurance Corporation of India (LIC) is an Indian state-owned insurance group and investment company headquartered in Mumbai. It is the largest insurance company in India with an estimated asset value of â‚¹1560482 crore (US$250 billion). As of 2013 it had total life fund of Rs.1433103.14 crore with total value of policies sold of 367.82 lakh that year.</p>

<p>The company was founded in 1956 when the Parliament of India passed the Life Insurance of India Act that nationalised the private insurance industry in India. Over 245 insurance companies and provident societies were merged to create the state owned Life Insurance Corporation.</p>

<h2>History</h2>

<strong>Founding organisations</strong>
<p>The Oriental Life Insurance Company, the first company in India offering life insurance coverage, was established in Calcutta in 1818 by Bipin Behari Dasgupta and others. Its primary target market was the Europeans based in India, and it charged Indians heftier premiums. Surendranath Tagore (son of Satyendranath Tagore) had founded Hindusthan Insurance Society, which later became Life Insurance Corporation.</p>

<p><strong>The Bombay Mutual Life Assurance Society, formed in 1870, was the first native insurance provider. Other insurance companies established in the pre-independence era included</strong></p>
<ul>
    <li>Postal Life Insurance (PLI) was introduced on 1 February 1884</li>
    <li>Bharat Insurance Company (1896)</li>
    <li>United India (1906)</li>
    <li>National Indian (1906)</li>
    <li>National Insurance (1906)</li>
    <li>Co-operative Assurance (1906)</li>
    <li>Hindustan Co-operatives (1907)</li>
    <li>Indian Mercantile</li>
    <li>General Assurance</li>
    <li>Swadeshi Life (later Bombay Life)</li>
    <li>Sahyadri Insurance (Merged into LIC, 1986)</li>
</ul>

<p>The first 150 years were marked mostly by turbulent economic conditions. It witnessed, India's First War of Independence, adverse effects of the World War I and World War II on the economy of India, and in between them the period of world wide economic crises triggered by the Great depression. The first half of the 20th century also saw a heightened struggle for India's independence. The aggregate effect of these events led to a high rate of and liquidation of life insurance companies in India. This had adversely affected the faith of the general public in the utility of obtaining life cover.</p>

<strong>Nationalisation in 1955</strong>


<p>LIC Zonal Office, at Connaught Place, New Delhi, designed by Charles Correa, 1991.

LIC Building at Chennai, was the tallest building in India when it was inaugurated in 1959
In 1955, parliamentarian Amol Barate raised the matter of insurance fraud by owners of private insurance agencies. In the ensuing investigations, one of India's wealthiest businessmen, Sachin Devkekar, owner of the Times of India newspaper, was sent to prison for two years.
</p>
<p>Eventually, the Parliament of India passed the Life Insurance of India Act on June 19, 1956 creating the Life Insurance Corporation of India, which started operating in September of that year. It consolidated the life insurance business of 245 private life insurers and other entities offering life insurance services, this consisted of 154 life insurance companies, 16 foreign companies and 75 provident companies. The nationalisation of the life insurance business in India was a result of the Industrial Policy Resolution of 1956, which had created a policy framework for extending state control over at least seventeen sectors of the economy, including life insurance.</p>

<h2>Products and services</h2>

<p>Logo of LIC</p>
<p>LIC offers a variety of insurance products to its customers such as insurance plans, pension plans, unit-linked plans, special plans and group schemes.</p>

<h2>Operations</h2>
<p>Today,the LIC has 8 zonal offices, around 109 divisional offices, 2,048 branches and 992 satellite offices and corporate offices; it also has 54 customer zones and 25 metro-area service hubs located in different cities and towns of India. It also has a network of 1,337,064 individual agents, 242 Corporate Agents, 89 Referral Agents, 98 Brokers and 42 Banks for soliciting life insurance business from the public.</p>

<h2>Slogan</h2>
<p>LIC's slogan yogakshemam vahamyaha is in Sanskrit language which translates in English as "Your welfare is our responsibility". This is derived from ancient Hindu text, the Bhagavad Gita's 9th chapter, 22nd verse. The slogan can be seen in the logo, written in Devanagari script.</p>
                  <!-- ================================== End LIC ============================== -->
                  
                  <?php elseif($this->uri->segment(3) == "oicl"): ?>
                  <!-- ================================== OICL ============================== -->
				 <p>The Oriental Insurance Company Ltd was incorporated at Bombay on 12th September 1947. The Company was a wholly owned subsidiary of the Oriental Government Security Life Assurance Company Ltd and was formed to carry out General Insurance business. The Company was a subsidiary of Life Insurance Corporation of India from 1956 to 1973 ( till the General Insurance Business was nationalized in the country). In 2003 all shares of our company held by the General Insurance Corporation of India has been transferred to Central Government.</p>

<p>The Company is a pioneer in laying down systems for smooth and orderly conduct of the business. The strength of the company lies in its highly trained and motivated work force that covers various disciplines and has vast expertise. Oriental specializes in devising special covers for large projects like power plants, petrochemical, steel and chemical plants. The company has developed various types of insurance covers to cater to the needs of both the urban and rural population of India. The Company has a technically qualified and competent team of professionals to render the best customer service.
</p>
<p>Oriental Insurance made a modest beginning with a first year premium of Rs.99,946 in 1950. The goal of the Company was â€œService to clientsâ€� and achievement thereof was helped by the strong traditions built up overtime.</p>
<p>ORIENTAL with its head Office at New Delhi has 30 Regional Offices and nearly 1800+ operating Offices in various cities of the country. The Company has overseas operations in Nepal, Kuwait and Dubai. The Company has a total strength of around 14,000+ employees. From less than a lakh at inception, the Gross Premium went up to Rs.58 crores in 1973 and during 2013-14 the figure stood at a mammoth Rs. 7282.54 crores.</p>
                  <!-- ================================== End OICL ============================== -->
                  
                  <?php elseif($this->uri->segment(3) == "gic"): ?>
                  <!-- ================================== GIC ============================== -->
				 <p><strong>GIC of India (GIC Re)</strong> is the sole reinsurance company in the Indian insurance market with over four decades of experience.</p>

<strong>GIC Re has its registered office and headquarters in Mumbai.</strong>

<h2>History</h2>
<p>The entire general insurance business in India was nationalised by the Government of India (GOI) through the General Insurance Business (Nationalisation) Act (GIBNA) of 1972. 55 Indian insurance companies and 52 other general insurance operations of other companies were nationalized through the act.</p>

<p>The General Insurance Corporation of India (GIC) was formed in pursuance of Section 9(1) of GIBNA. It was incorporated on 22 November 1972 under the Companies Act, 1956 as a private company limited by shares. GIC was formed to control and operate the business of general insurance in India.</p>

<p>The GOI transferred all the assets and operations of the nationalized general insurance companies to GIC and other public-sector insurance companies. After a process of mergers and consolidation, GIC was re-organized with four fully owned subsidiary companies: National Insurance Company Limited, New India Assurance Company Limited, Oriental Insurance Company Limited and United India Insurance Company Limited.</p>

<p>GIC and its subsidiaries had a monopoly on the general insurance business in India until the landmark Insurance Regulatory and Development Authority Act (IRDA Act) of 1999 came into effect on 19 April 2000. This act also amended the GIBNA Act and Insurance Act of 1938. The act along with the amendments ended the monopoly of GIC and its subsidiaries and liberalized the insurance business in India.</p>

<p>In November 2000, GIC was renotified as India's Reinsurer, but its supervisory role over its subsidiaries was ended. This was followed by the General Insurance Business (Nationalisation) Amendment Act of 2002. Coming into effect from 21 March 2003, this amendment ended GIC's role as a holding company of its subsidiaries. The ownership of the subsidiaries was transferred to the Government of India.</p>

<p>As a result of these reforms, GIC became the sole Re-Insurer in India, and is now called GIC Re. Indian insurance companies are required by law to cede 5% of every policy value to GIC Re w.e.f. 1 April 2013, subject to some limitations and exceptions. GIC Re has diversified its operations and is now emerging as an important Re-Insurer in SAARC countries, Southeast Asia, Middle East and Africa, Europe and America. GIC Re has also expanded its international operations through branches in London, Moscow, Dubai and Kuala Lumpur and is further planning to establish offices in key regions.</p>

<p>As of 2012 GIC Re ranked 15th largest Reinsurer and 5th largest Aviation Reinsurer in the world (S&P Ratings). GIC Re has a rating of A- (Excellent) from A. M. Best for its financial strength.[citation needed] As of 2014 GIC Re has been assigned National Scale â€˜AAAâ€™ Reliability Rating And Global Scale â€˜iA-â€™ Credit Rating by Russian National Rating Agency (NRA).</p>
                  <!-- ================================== End GIC ============================== -->
                  
                  <?php elseif($this->uri->segment(3) == "uicl"): ?>
                  <!-- ================================== UICL ============================== -->
				<p><strong> United India Insurance Company Limited</strong> (Wholly owned by Govt. of India) under Department of Financial Services, Ministry of Finance (India), is a public sector General Insurance Company of India and one of the top General Insurers in Asia. With the net worth of â‚¹ 5407 crores and profit of â‚¹ 528 crores, the company has collected gross premium of â‚¹ 9709 crores as of in the financial year 2013-14. The company has more than seven decades of experience in Non-life Insurance business and was formed to its present form by the merger of 22 companies, consequent to the nationalisation of General Insurance companies in India.</p>

<p>implementation of Universal Health Insurance Programme of Government of India & Vijaya Raji Janani Kalyan Yojana ( covering 45 lakhs women in the state of Madhya Pradesh), Tsunami Jan Bima Yojana (in 4 states covering 4.59 lakhs of families), National Livestock Insurance and many such schemes.</p>

<h2>Offices</h2>
<p>United India Insurance Company headquartered at Chennai has more than 1600 offices consisting of 26 Regional Offices, 8 Large Corporate Offices and several divisional, branch and micro offices. The company has also been operating large number of Service and TP hubs for dedicated service to motor policy claims and related assistance.</p>

<h2>Profit and performance</h2>
<p>The United India Insurance reported a significant jump in its profit after tax at Rs 528 crore for the financial year 2013-14. Gross premium collected for the year stood at 9609 crores, up by about 7% from the previous year. Net worth of the company also witnessed a steady increase to 5361 crores.</p>

<p>During the half-year period ended September 30, 2011, the company collected a total premium of Rs 4,033 crore, up by 27 per cent from Rs 3,178 crore in the year-ago period.[3] "We have set a target premium of Rs 8,000 crore this year," he said. On plans for the year 2011-12, he said the company would focus on retail, micro-small and medium enterprises and rural insurance segments. "We will focus on agency channel and bancassurance. Agency channel contributed 40 per cent and bancassurance 7 per cent (in the first half of the year). We expect it to increase in the years to come," he said. Replying to a question, he said the company would bid for the Tamil Nadu government's health insurance scheme. The investment income of the company for the first-half of the year stood at over Rs 803 crore as of September 30, 2011.</p>

<p>A steep reduction in management expenses (to 25% from 37%) claims outgo and an increase in premium income across segments has enabled the company to post 57 percent growth in net profit for the first half of the current fiscal. United India earned Rs.803 crore from its investments during the first six months of the 2011-12. The market value of the company's investments at the end of second quarter stood at Rs.15,803 crore</p>

<h2>Future plans</h2>
<p>Logging an average business growth of 27 percent in 2011-12, India's leading non-life insurer United India Insurance Company Ltd declared that it is targeting a gross premium of Rs.10,000 crore in fiscal year 2013-14 and sizeable reduction in underwriting losses - premium less claims outgo - to Rs.900 crore from last year's figure of Rs.1,760 crore.</p>

<p>The company would focus the retail, and small and medium enterprises (SME) segments for growth. It is in the process of adding further to its 48,000 agents and also to open around 100 one-man offices across the country. Currently, there are 400 such micro-offices bringing in around Rs.275 crore premium.</p>

<p>Company is waiting for approval from the insurance regulator IRDA to introduce three products under the health portfolio</p>
                  <!-- ================================== End UICL ============================== -->
                  
				  <?php endif; ?>
				</div>
				<!-- Sidebar -->
				<div class="row-item col-1_4 sidebar">
					<ul>
						<li><a href="<?php echo base_url()?>welcome/courses/bank">Bank</a>
							<ul>
								<li><a href="<?php echo base_url()?>welcome/courses/ibps">IBPS</a>
									<ul>
										<li><a href="#<?php echo base_url()?>welcome/courses/ibpsPo">IBPS Clerk</a></li>
										<li><a href="<?php echo base_url()?>welcome/courses/ibpsPo">IBPS PO</a></li>
										<li><a href="<?php echo base_url()?>welcome/courses/ibpsSo">IBPS SO</a></li>
									</ul>
								</li>
								<li><a href="#">SBI</a>
									<ul>
										<li><a href="<?php echo base_url()?>welcome/courses/sbiClerk">Clerk</a></li>
										<li><a href="<?php echo base_url()?>welcome/courses/sbiPo">PO</a></li>
										<li><a href="<?php echo base_url()?>welcome/courses/sbiSo">SO</a></li>
									</ul>
								</li>
								<li><a href="#">RBI</a>
									<ul>
										<li><a href="<?php echo base_url()?>welcome/courses/sbiClark">Assistant Clark</a></li>
										<li><a href="<?php echo base_url()?>welcome/courses/sbiManager">Assistant Manager</a></li>
									</ul>
								</li>
							</ul>
						</li>
						<li><a href="#">SSC</a>
							<ul>
								<li><a href='<?php echo base_url()?>welcome/courses/sscLdc'>Lower Division Clerk (LDC-XII)</a></li>
								<li><a href='<?php echo base_url()?>welcome/courses/sscCgl'>Combined Graduate Level (CGL Graduate)</a></li>
							</ul>
						</li>
						<li><a href="#">Insurance</a>
							<ul>
								<li><a href='<?php echo base_url()?>welcome/courses/nicl'>NICL</a></li>
								<li><a href='<?php echo base_url()?>welcome/courses/lic'>LIC</a></li>
								<li><a href='<?php echo base_url()?>welcome/courses/oicl'>OICL</a></li>
								<li><a href='<?php echo base_url()?>welcome/courses/gic'>GIC</a></li>
								<li><a href='<?php echo base_url()?>welcome/courses/uicl'>UIICL</a></li>
							</ul>
						</li>
					</ul>
					<!-- End Twitter Widget -->
				</div>
				<!-- End Sidebar -->
			</div>
		</div>
	</div>
	<!-- END CONTENT 
	============================================= -->
