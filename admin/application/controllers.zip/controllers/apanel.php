<?php
class Apanel extends CI_Controller{
	
	public function index(){
		$data['title'] = "Dashboard";
		$data['smallTitle'] = "Dashboard";
		$data['bigTitle'] = "Dashboard";
		$data['body'] = "admin/dashboard";
		$data['headerCss'] = "admin/headerCss/dashboardCss";
		$data['footerJs'] = "admin/footerJs/dashboardJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function studentRegister(){
		$data['title'] = "New Student Registration";
		$data['smallTitle'] = "Student Registration";
		$data['bigTitle'] = "Student Registration";
		$data['body'] = "admin/studentRegister";
		$data['headerCss'] = "admin/headerCss/studentRegisterCss";
		$data['footerJs'] = "admin/footerJs/studentRegisterJs";
		$this->load->view("include/admin/mainContent",$data);
	}

	public function printRegister(){
		$data['title'] = "Student Profile";
		$data['smallTitle'] = "Student Profile/Admission Invoice";
		$data['bigTitle'] = "Student Profile/Admission Invoice";
		$data['body'] = "printRegister";
		$data['headerCss'] = "admin/headerCss/dashboardCss";
		$data['footerJs'] = "admin/footerJs/dashboardJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function studentList(){
		$data['title'] = "Student List";
		$data['smallTitle'] = "Student List";
		$data['bigTitle'] = "Student List";
		$data['body'] = "admin/studentList";
		$data['headerCss'] = "admin/headerCss/studentListCss";
		$data['footerJs'] = "admin/footerJs/studentListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function headline(){
		$data['title'] = "Website Headline";
		$data['smallTitle'] = "Website/Headline";
		$data['bigTitle'] = "Website Headline";
		$data['body'] = "admin/headline";
		$data['headerCss'] = "admin/headerCss/studentRegisterCss";
		$data['footerJs'] = "admin/footerJs/studentRegisterJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function inquiry(){
		$data['title'] = "Inquiry List";
		$data['smallTitle'] = "Website/Inquiry List";
		$data['bigTitle'] = "Inquiry List";
		$data['body'] = "admin/inquiry";
		$data['headerCss'] = "admin/headerCss/studentListCss";
		$data['footerJs'] = "admin/footerJs/studentListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function vacancies(){
		$data['title'] = "Vacancies";
		$data['smallTitle'] = "Website/Vacancies";
		$data['bigTitle'] = "Vacancies";
		$data['body'] = "admin/vacancies";
		$data['headerCss'] = "admin/headerCss/studentRegisterCss";
		$data['footerJs'] = "admin/footerJs/studentRegisterJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function freeDemo(){
		$data['title'] = "Demo Class List";
		$data['smallTitle'] = "Website/Demo Class List";
		$data['bigTitle'] = "Free Demo List";
		$data['body'] = "admin/freeDemo";
		$data['headerCss'] = "admin/headerCss/studentListCss";
		$data['footerJs'] = "admin/footerJs/studentListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function career(){
		$data['title'] = "Career";
		$data['smallTitle'] = "Website/Career List";
		$data['bigTitle'] = "Applied Career Option";
		$data['body'] = "admin/career";
		$data['headerCss'] = "admin/headerCss/studentListCss";
		$data['footerJs'] = "admin/footerJs/studentListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function contact(){
		$data['title'] = "Contact";
		$data['smallTitle'] = "Website/Contact Form List";
		$data['bigTitle'] = "Contact Form List";
		$data['body'] = "admin/contact";
		$data['headerCss'] = "admin/headerCss/studentListCss";
		$data['footerJs'] = "admin/footerJs/studentListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function createTest(){
		$data['title'] = "Create Test";
		$data['smallTitle'] = "Create Test/Create Test";
		$data['bigTitle'] = "Create Test";
		$data['body'] = "admin/createTest";
		$data['headerCss'] = "admin/headerCss/studentRegisterCss";
		$data['footerJs'] = "admin/footerJs/createTestJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function testList(){
		$data['title'] = "Test List";
		$data['smallTitle'] = "Create Test/Test List";
		$data['bigTitle'] = "Test List";
		$data['body'] = "admin/testList";
		$data['headerCss'] = "admin/headerCss/studentListCss";
		$data['footerJs'] = "admin/footerJs/studentListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function enterQuestion(){
		$data['title'] = "Enter Question";
		$data['smallTitle'] = "Create Test/Enter Question";
		$data['bigTitle'] = "Enter Question";
		$data['body'] = "admin/enterQuestion";
		$data['headerCss'] = "admin/headerCss/enterQuestionCss";
		$data['footerJs'] = "admin/footerJs/enterQuestionJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function questionList(){
		$data['title'] = "Question List";
		$data['smallTitle'] = "Create Test/Question List";
		$data['bigTitle'] = "Question List";
		$data['body'] = "admin/questionList";
		$data['headerCss'] = "admin/headerCss/questionListCss";
		$data['footerJs'] = "admin/footerJs/questionListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
	
	public function selectTest(){
		$data['title'] = "Test";
		$data['smallTitle'] = "Test/Go for test";
		$data['bigTitle'] = "Select Test";
		$data['body'] = "admin/selectTest";
		$data['headerCss'] = "admin/headerCss/questionListCss";
		$data['footerJs'] = "admin/footerJs/questionListJs";
		$this->load->view("include/admin/mainContent",$data);
	}
}

