<?php
class loginController extends CI_Controller{
	public function stuLogin(){
		$data['body'] = "vacancies";
		$this->load->view('include/template',$data);
	}
	
	public function login(){
		
	}
}