<?php
class InvoiceController extends CI_Controller{
	
	public function registerC(){
		$data['studentId'] = $this->uri->segment(3);
		$this->load->view("invoice/registerC",$data);
	}
}