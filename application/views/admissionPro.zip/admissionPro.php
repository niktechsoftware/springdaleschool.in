<div id="main" class="round_8 clearfix">
            <div class="page_title round_6">
                <h1 class="replace">School Process & Student Studies.</h1>
            </div>
           <center> <h2>   REGISTRATION FORM</h2> </center>
       <b> <p>The form should be filled in capital letter</p></b>
       <form method="post" action="<?php echo base_url();?>index.php/welcome/regisenquiry">
       
           
<label><b>Student name:</b></label>

<input type="text" name="name" placeholder ="enter name" class="form-control" size="70px">
<span></span><span></span>
<br><br>
        <label><b>Date of birth:</b></label>

<input type="date" name="dob" placeholder ="D.O.B" class="form-control" size="35px">

      <label><b>&nbsp&nbsp&nbsp&nbsp Age:</b></label>

<input type="text" name="age" placeholder ="Age" class="form-control" size="35px">
     
        <br><br>
         <label><b>Addmission for class:</b></label>

<input type="text" name="addmission" placeholder ="Admission class" class="form-control" size="25px">
<br><br>
 <label><b>Gender(male/female):</b></label>

<input type="text" name="gender" placeholder ="Gender" class="form-control" size="25px">
<br><br>
 <label><b>Nationality:</b></label>

<input type="text" name="nation" placeholder ="Nationality" class="form-control" size="25px">
<br><br>
<b><h4 style="color:black">FATHER'S DETAIL</h4></b>
<br>
<label><b>Father name:</b></label>

<input type="text" name="fname" placeholder ="Father name" class="form-control" size="70px">
<br><br>
<label><b>Occupation:</b></label>

<input type="text" name="foccupation" placeholder ="occupation" class="form-control" size="35px">

<label><b>&nbsp&nbsp&nbsp&nbsp  Education:</b></label>

<input type="text" name="education" placeholder ="Education" class="form-control" size="35px">
<br><br>
<label><b>Language spoken at home:</b></label>

<input type="text" name="flanguage" placeholder ="Language" class="form-control" size="25px">
<br><br>
<label><b>Residential address:</b></label>

<input type="text" name="radd" placeholder ="Residential address" class="form-control" size="45px">
<br><br>
<label><b>Contact Detail:</b></label>

<input type="text" name="cond" placeholder ="Contact Detail" class="form-control" size="45px">
<label><b>&nbsp&nbsp&nbsp&nbsp Phone no.:</b></label>

<input type="number" name="phone" placeholder ="Phone number" class="form-control" size="35px">
<br><br>
<label><b>Mobile number:</b></label>

<input type="number" name="mobile" placeholder ="Mobile number" class="form-control" size="45px">
<label><b>&nbsp&nbsp&nbsp&nbsp Email.:</b></label>

<input type="email" name="email" placeholder ="email" class="form-control" size="35px">
<br><br>
<b><h4 style="color:black">MOTHER'S DETAIL</h4></b>
<br>
<label><b>Mother name:</b></label>

<input type="text" name="mname" placeholder ="Mother name" class="form-control" size="70px">
<br><br>
<label><b>Occupation:</b></label>

<input type="text" name="moccupation" placeholder ="occupation" class="form-control" size="35px">

<label><b>&nbsp&nbsp&nbsp&nbsp  Education:</b></label>

<input type="text" name="meducation" placeholder ="Education" class="form-control" size="35px">
<br><br>
<label><b>Language Spoken at home:</b></label>

<input type="text" name="mlanguage" placeholder ="language" class="form-control" size="35px">


<br><br>
<center>
<input type="submit" name="sub" class="bg-info">

</center>


          
            <div class="clear"></div>
            <hr class="pad"/>
            <h2>.</h2>
            <div class="full">
      <b>
            MISSIONS STATEMENT -</b>
Our primary duty is to inculcate positive virtues like courage, vitality, sensitiveness and creativity in children so that they grow into visionary leaders of upright character.<br>
Education in its real sense implies acquisition of knowledge, developing powers of reasoning and character building there by, transforming one into an enlightened human being.  Nuclear age of today character building demands education to transcend from its traditional role to fuse the modern day student with scientific temperament, while retaining our core values to prepare him for the task of nation building which is the crying need of the hour.<br>
We at SDS endeavour to build upright citizens who aspire for a higher and a better life, guest for knowledge, perfection and spread of universal brotherhood.<br><br><b>
INTRODUCTION -</b>
The true essence of a school lies, not in its infrastructure of four walls but its overall purpose of imparting quality education which includes the art of shaping  individual’s personality through physical, emotional, intellectual and spiritual development. The school, therefore, devotes itself assiduously to grooming of students in such a way that they excel in all walks of life, make a mark in every field of human activity and become proud citizens of the twenty first century not only infused with qualities of character, but also a capability to withstand the onslaught of modern day degeneration of values, The true riches of this institution lie in producing gentle Beasians who are truthful and represent the school motto ‘Truth is God’ The hallmark of finished products of this institution is an upright character, confidence, analytical mind and concern for fellow beings.<br><br><b>
BACKGROUND -</b>
Army public School Beas is the brain child of late Gen BC Joshi,PVSM,AVSM,ADC, the then Chief of the Army Staff. The foundation stone was laid on 06 NOV 93 by Ben BC Joshi. Finally, on 10 July 95, the school was inaugurated by Lt Gen HB Kala, OVSM, AVSM, SC the then GOC 11 Corps and exactly after a year in July 1996 an adhoc hostel was made functional.<br>
Army Public School Beas is residential co-educational English Medium School Affiliated to CBSE with classes from V to Xll and functions under the aegis of Army Welfare Education Society (AWES). The school offers Science, Commerce and Humanities streams.<br> Primarily started for the children of serving and retired army personnel, the school has a fair sprinkling of civilian. Children from J&K sponsored under Operation Sadbhavana are also studying in the school.<br>
Army Public Beas has an aesthetic layout with modern and latest educational technologies to help the students attain their optimum academic potential and imbibe moral, social and ethical values, and ideal mix of tradition with modernity
<br><br><b>
LOCATION AND INFRASTRUCTURE -</b><p>
The school is located on National Highway No.1 about 8 km from Beas towards Jalandhar. Sprawled on the 14 acres lush green grounds in a tranquil ambience the school is housed in modern sophisticated buildings.</p><p>
The school has spacious and airy classrooms furnished with comfortable furniture and magnetic enamel chalkboards, well stocked Library, Art and Craft room, computer Labs with internet facility and the state of art language lab.</p><p> The school has excellent infrastructure by way of multipurpose auditorium, basketball courts, play fields which provide opportunities to all to excel in sports and co-curricular activities.</p><br>
<b>
AIMS AND OBJECTIVES -</b><p>
To provide quality education at affordable cost by the use of modern and progressive educational techniques to achieve excellence in studies and all round development of students to make them good citizens of our country.</p><p>
The school prepares the children for All India Secondary School Examination.(Class X) CONDUCTED BY THE Central Board of Secondary Education, Delhi,
The aim is to produce disciplined children who are punctual, gentle, truthful and sincere to themselves, their colleagues and the country.
</p><br><b>
ADMISSION POLICY -</b>
Admission to various classes starts at the beginning of the academic session in March/April every year. Admission tests are held in Feb and Apr followed by an interview.

<br><br>


           
           <p align="justify"><b>Age eligibility -</b>The student should complete the under mentioned year of age on 31 of the year in which admission is sought as given against each class:-    <br>  <h3>  Play group to IX</h3>
  <br>    P.G       __________2.5 Years<br>
            Nurs    __________3 Years<br>
  L.K.G ___________4 Years<br>
  U.K.G ___________5 Years<br>
  1.       ___________6 Years<br>
  2.     ___________7 Years<br>

                              3.    ____________8 Years<br>
                            4.   ___________9 Years<br>
                            Class V                       : 10 Years<br>
                            Class VI                     : 11 Years <br>
                            Class VII                   : 12 Years<br>
                            Class VIII                 : 13 Years   <br>
                            Class IX                   : 14 Years <br>
Class X                   : 15 Years    <br>                          
                          
                          
<br><b>
ENTRANCE TESTS  FOR CLASSES V TO IX -</b>
For admissions to class P.G for entrance test, class, NUR, to appear for a test in English, Hindi, Mathematics, and General Awareness. Apart from above mentioned subjects, candidates seeking admission to class VII_X will be tested in the subject of Science and Social Science also. The syllabus for the same would be of the class deemed to have been cleared by the applicant (COSE Syllabus)
<br><br><b>
LANGUAGE LAB -</b>
With the view to hone the language skills of the students and I, prove their proficiency in various language they are given regular practice in the Language Lab in various skills I.e. Listening, Speaking, Reading and Writing.
TECHONOLOGY AIDED LEARNING (TAL)
Technology Aided Learning (TAL) are a regular feature of the school curriculum. Digital Classrooms for all classes &subjects are being used by teachers which make teaching learning more effective and long lasting.
<br><br><b>
CLASS  1 TO X: -</b>
Continuous and Comprehensive Evaluation is being carried out for all classes from 1 to X as per the guidelines issued by the CBSE from time to ‘time. Evaluation of Academic subjects will be carried out in 4 assessments distributed over two terms. Each term will have weightage comprising of two Formative Assessments of 25% each and a Summative Assessments of 25% weightage. Co-scholastic activities, attitudes & values and health & physical education will also be evaluated once a year. Promotion will be based on the day-t-day work of the students throughout the year and also on the performance in the terminal examination.
<br><br><b>
AWARDS & SCHOLARSHIPS -</b>
Every year in the month of March, students excelling in academics and co-curricular activities are awarded merit certificates during the annual prize distribution.
<br><br><b>CO-CURRICULAR ACTIVIES -</b><p>
Tours and Treks, Twice in year arrangements are made for students to participate in various camps organized at scenic places. Apart from this educational trips and picnics are also organized regularly for students. Details of these trips are finalized and arrangements are made on receipt of confirmation from parents in advance, these educational tours are made t make the students aware of our rich heritage and rapid transformation.</p>
Inter House Activates and Inter School Competitions. The school has an activity schedule for the whole year. These are conducted on Wednesday/Saturdays, under the supervision of teachers. These activities aim to develop physical, literary and artistic skills of the students. the school also participates in inter-school and inter-zonal competitions which help the students to develop aesthetic appreciation and self confidence.<br><br>

<b>
HOSTEL -</b>
The school Hostel is situated in the residential area. The complete Hostel is divided into five different Hostels for boys and Girls Hostel.’ There are around 75 students in each House. A Housemaster looks after basic administration of his respective House.<br>
<p>Each House has 2-seater, 4-seater and 8-seater rooms, Each student in his/her respective dorm is provide with a bed, an almirah,  a study table and a chair, Generator power Backup is provided for lights, fans and cold drinking water as and when required.</p><p>Dorm-attendants look after the general cleanliness and laundry facilities of the boarders. Services of barber and cobbler are provided in the hostel on regular basis.</p><br>

<b>
MESS -</b>
Two well laid out dining halls with efficient mess staff, supervised by the Mess Supervisor, caters to the meals of the boarders. The state of the art kitchen is well equipped with modern gadgets including a baking unit. Meals are prepared keeping in mind hygiene and balanced nutritious diet to meet the requirement or children of all age groups. Both vegetarian and non vegetarian food is provided to the boarders as per their choice. Teachers on duty also have their meals in the dining hall along with the boarders to inculcate mess etiquettes.<p>A Multi- facility, Ultra- modern Kitchen: A State of the art fully automatic ‘Chapatti Making Machine’ has been installed in the Mess Kitchen so as to maintain high standards of hygiene.
</p>

<br>
<b>
GAMES AND SPORTS -</b></br>
(a) Regular games and physical training are compulsory for all students. <br><br>
(b) There are volleyball courts, two badmintion courts, one tennis court, four basketball cemented courts, one football field, one hockey field, a cricket pitch and a gymnasium. The school also provides facilities for yoga, swimming and Equestrians Club (Horse riding Club). To bring out sportsmanship and competitiveness, our teams participate in inter school, zonal,. Regional and national level competitions. Opportunities are given to they children to develop an all round personality and become proficient in games and sports.
<br>
<br>
<br><b>
HOUSE SYSTEM -</b>
All the students of the school are divided into four Houses which are named after four Eminent Personalities of India i.e. Kautily, Kasturba, Kalpana & Kalam Each House is looked after by a House Master & Mistress and a team of tutors. This concept of Houses provides opportunities for better organizations and healthy competitions. 
<br><br>
<b>
SUPERVISED STUDY -</b>
There is a system of supervised study for duration of two hours in the afternoon/ evening with a view to lay foundation for self study.<p>
The teaching staff is engaged to supervise these students during the afternoon/evening preps which are conducted five times a week. Special remedial classes are organized for weak students in the afternoons/zero periods.</p><p>
Apart from this, to provide additional coaching to board classes, summer and winter study camps are organized in consultation with students. Experts in their fields are also co-opted on required basis.</p><br><b>MEDICAL FACILITIES -</b>
The school has an MI room within the campus where medical aid is provide. All students are subjected to a thorough medical checkup once a year. Backup medical support is also provided,<br>
<br><b>BREAK AND VACTIONS -<b></br><p>
In addition to normal gazette holidays, the school observes the following vacations breaks:</p>
<p>(a) Summer vacation-May-June 50 days</p>
<p>(b) Autumn Break- Oct-Nov 10 days</p>
<p>(c) Winter Break – Dec-Jan 10 days</p>
The school remains closed only for faculty members and students. The office functions as usual and administrative staff observe only gazette holidays.<br><br>
<b>
SCHOOL MAGAZINE -</b>
<p>
Our school magazine Book name is published annually and is a useful record of school activities conducted throughout the academic session. The compilation is done by the Students Editorial Board under the guidance of Staff Advisory Board.</p><p>
The school also publishes a monthly newsletter ‘The Beasian Times’</p>
SCHOOL RULES<br><br><b>
LEAVE: -</b>
(a) Students are not encouraged to make any request for leave of absence during the term. Even for medical visits, students should make suitable arrangement so as not to disturb the school routine.</br>
(b) The name of the students will be deleted from the school record if they are absent for six consecutive days, without prior permission.</br>
(c) In case of a marriage or any other family function, boarders, should take permission otherwise absent is marked</br></br><b>
PAYMENT OF FEE:-</b><p>
(A) The name of the pupil shall be struck off if fee is not paid for three consecutive months on first day of the month.</p>
<p>(b) In case of late fees, a fine of RS-…..  is charged for delay of each month.</p><p><b>
TRANSFER CERTIFICATE -</b><p>
(A) Parents should apply for TC on the prescribed form available at the school.</p>
(b) TC is generally issued within 3 days on receipt of application form from parents.<br><br><b>
PARENTS  RESPONSIBILITY -</b><p>
(A) Kindly ensure that your child attends school neatly, both in person and list of uniform/articles required is given in Appendix A.</p><p>
(b) you requested to regularly check the child’s performance in academic and curriculum activities.</p><p>
(c) Children are not suppose to get valuable to the school. The school accepts no responsibility whatsoever for loss of valuables brought to school.</p><p>
(d) Please don’t gibe electronic items (Mobile, MP3 player, etc) to your ward. If found with children, these will be confiscated and will not be returned.</p><p>
(e) Parents are not allowed to go to the class rooms for any reasons. They shall contact the Principal in case of any urgency.</p><p>
(f) Parents are requested to ensure that their ward utilizes vacation period for studies and completing the home work.</p><p>
(g) Parents are requested to send their wards back to school on due date after each vacation/break failing which the pupil would be fined RS100/-per day of absence.</p><p>
(h) Parents are requested to read the Student’s Diary regularly.</p><br><b>
VISITING/CALLING HOURS:-</b><p>
(A) Regular Parent-Teacher meeting is organized on every Second Saturday. Parents can also visit their wares on Second Saturday of the month. They can also interact with the teachers and housemasters.</p><p>
(b) Parents can call you their wards on weekdays from 8.45pm to 10,00pm hrs to 2200 hrs and on Sundays & holidays from 100hrs to 10:00am to 01:00pm.
</p><br><b>OFFICE HOURS:-</b><p>
(i) Summer: 9:30 to 2:00 pm</p>
(II) winter: 8:30 to 3:30 pm

<br><br>
<!--<table id="AutoNumber1" width="99%" border="0" cellspacing="0" cellpadding="0">-->


                 </div>
        </div>